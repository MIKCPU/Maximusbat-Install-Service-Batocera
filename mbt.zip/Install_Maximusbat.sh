#!/bin/bash
# --- Maximusbat EmulationStation xterm launcher ---
if [ "${MBT_XTERM:-0}" != "1" ] && ps -p "$PPID" -o args= 2>/dev/null | grep -q "emulatorlauncher"; then
    exec /usr/bin/xterm -fs 16 -maximized -fg white -bg black -fa DejaVuSansMono -en UTF-8 -e env MBT_XTERM=1 /bin/bash "$0" "$@"
fi
# --- Fine launcher ---

BASE="/userdata/roms/mbt"

logo() {
    clear
    echo -e "\e[32m"
    echo
    echo "                              ##     ## #### ##    ##  ######  ########  ##     ## "
    echo "                              ###   ###  ##  ##   ##  ##    ## ##     ## ##     ## "
    echo "                              #### ####  ##  ##  ##   ##       ##     ## ##     ## "
    echo "                              ## ### ##  ##  #####    ##       ########  ##     ## "
    echo "                              ##     ##  ##  ##  ##   ##       ##        ##     ## "
    echo "                              ##     ##  ##  ##   ##  ##    ## ##        ##     ## "
    echo "                              ##     ## #### ##    ##  ######  ##         #######"
    echo
    echo -e "\e[93m                                          PRESENT  -  PRESENTA\e[0m"
    echo
    echo -e "\e[91m"
    echo "           ##     ##    ###    ##     ## #### ##     ## ##     ##  ######  ########     ###    ######## "
    echo "           ###   ###   ## ##    ##   ##   ##  ###   ### ##     ## ##    ## ##     ##   ## ##      ##    "
    echo "           #### ####  ##   ##    ## ##    ##  #### #### ##     ## ##       ##     ##  ##   ##     ##    "
    echo "           ## ### ## ##     ##    ###     ##  ## ### ## ##     ##  ######  ########  ##     ##    ##    "
    echo "           ##     ## #########   ## ##    ##  ##     ## ##     ##       ## ##     ## #########    ##    "
    echo "           ##     ## ##     ##  ##   ##   ##  ##     ## ##     ## ##    ## ##     ## ##     ##    ##    "
    echo "           ##     ## ##     ## ##     ## #### ##     ##  #######   ######  ########  ##     ##    ##    "
    echo -e "\e[0m"
    echo

    echo -e "\e[93m                                      FOR  - PER "BATOCERA"\e[0m"
    echo
}

pause_continue() {
    echo
    read -r -p "Premi INVIO per continuare... " _
}

read_gamepad_button() {
    local device="/dev/input/js0"
    local btn

    [ -e "$device" ] || return 1
    command -v jstest >/dev/null 2>&1 || return 1

    btn=$(timeout 2 jstest --event "$device" 2>/dev/null | grep -m1 "button" | awk '{print $3}')
    [ -n "$btn" ] || return 1

    printf '%s\n' "$btn"
    return 0
}

run_script() {
    local script="$1"

    if [ ! -f "$script" ]; then
        echo
        echo "Errore: script non trovato"
        echo "$script"
        pause_continue
        return 1
    fi

    chmod +x "$script" 2>/dev/null

    echo
    echo "Avvio: $script"
    echo

    bash "$script"
    local rc=$?

    echo
    echo "Codice uscita: $rc"
    pause_continue
    return $rc
}

menu_tools_keyboard() {
    while true; do
        logo

        echo -e "\e[92m"
        echo "                                      UTILITY PROGRAMS / PROGRAMMI UTILI"
        echo
        echo -e "\e[93m"
        echo "             ==================================================================================="
        echo "             * 1. Default intro in Batocera         *  1. Intro predefinita in Batocera        *"
        echo "             * 2. Create SysLinks for Roms          *  2. Crea SysLinks per Roms               *"
        echo "             * 3. Invert Buttons A / B or Z / X     *  3. Inverti Pulsanti A / B o Z / X       *"
        echo "             * b. Back                              *  b. Indietro                             *"
        echo "             ==================================================================================="
        echo

        read -r scelta || exit 0

        case "$scelta" in
            1) run_script "$BASE/script/Make_Intro.sh" ;;
            2) run_script "$BASE/script/Batocera-Link-Tool.sh" ;;
            3) run_script "$BASE/script/swap_buttons.sh" ;;
            b|B) return 0 ;;
            *) ;;
        esac
    done
}

menu1() {
    while true; do
        logo

        echo
        echo -e "\e[93m"
        echo "               ===================================================================================="
        echo "               *                         INSTRUCTIONS / ISTRUZIONI                                *"
        echo "               *                        - First update the tool.                                  *"
        echo "               *                        - Then download the theme.                                *"
        echo "               *                        - Per prima cosa aggiorna il tool.                        *"
        echo "               *                        - Poi scarica il tema.                                    *"
        echo "               ===================================================================================="
        echo

        echo -e "\e[92m"
        echo "               ===================================================================================="
        echo "               * 1. Start Updater installation        *  1. Avvia installazione Updater           *"
        echo "               * 2. Start MaximusBat theme download   *  2. Avvia scaricamento tema MaximusBat    *"
        echo "               * 3. Add Images and Logos in Italian   *  3. Aggiungi immagini e loghi in Italiano *"
        echo "               * 4. Utility Programs                  *  4. Programmi Utili                       *"
        echo "               * b. Back                              *  b. Indietro                              *"
        echo "               * e. Exit                              *  e. Uscita                                *"
        echo "               ===================================================================================="
        echo

        read -r scelta || exit 0

        case "$scelta" in
            1) run_script "$BASE/script/maximusbat_update.sh" ;;
            2) run_script "$BASE/script/maximusbat_theme.sh" ;;
            3) run_script "$BASE/script/italian_add_images.sh" ;;
            4) menu_tools_keyboard ;;
            b|B) return 0 ;;
            e|E) exit 0 ;;
            *) ;;
        esac
    done
}

menu_tools_gamepad() {
    while true; do
        logo

        echo
        echo -e "\e[92m"
        echo "                                      UTILITY PROGRAMS / PROGRAMMI UTILI"
        echo
        echo -e "\e[93m"
        echo "             ==================================================================================="
        echo "             * A. Default intro in Batocera         *  A. Intro predefinita in Batocera        *"
        echo "             * B. Create SysLinks for Roms          *  B. Crea SysLinks per Roms               *"
        echo "             * Y. Invert Buttons A / B or Z / X     *  Y. Inverti Pulsanti A / B o Z / X       *"
        echo "             * START. Back                          * START. Indietro                          *"
        echo "             ==================================================================================="
        echo
        echo "Premi un pulsante del gamepad..."
        echo

        BTN=$(read_gamepad_button)

        if [ -z "$BTN" ]; then
            echo "Gamepad non rilevato o nessun input."
            pause_continue
            return 0
        fi

        case "$BTN" in
            0) run_script "$BASE/script/Make_Intro.sh" ;;
            1) run_script "$BASE/script/Batocera-Link-Tool.sh" ;;
            2) run_script "$BASE/script/swap_buttons.sh" ;;
            9) return 0 ;;
            *) ;;
        esac
    done
}

menu2() {
    while true; do
        logo

        echo
        echo -e "\e[93m"
        echo "               ===================================================================================="
        echo "               *                         INSTRUCTIONS / ISTRUZIONI                                *"
        echo "               *                        - First update the tool.                                  *"
        echo "               *                        - Then download the theme.                                *"
        echo "               *                        - Per prima cosa aggiorna il tool.                        *"
        echo "               *                        - Poi scarica il tema.                                    *"
        echo "               ===================================================================================="
        echo

        echo -e "\e[92m"
        echo "               ===================================================================================="
        echo "               * A. Start Updater installation        *  A. Avvia installazione Updater           *"
        echo "               * B. Start MaximusBat theme download   *  B. Avvia scaricamento tema MaximusBat    *"
        echo "               * Y. Add Images and Logos in Italian   *  Y. Aggiungi immagini e loghi in Italiano *"
        echo "               * X. Utility Programs                  *  X. Programmi Utili                       *"
        echo "               * SELECT. Back                         *  SELECT. Indietro                         *"
        echo "               * START. Exit                          *  START. Uscita                            *"
        echo "               ===================================================================================="
        echo
        echo "Premi un pulsante del gamepad..."
        echo

        BTN=$(read_gamepad_button)

        if [ -z "$BTN" ]; then
            echo "Gamepad non rilevato o nessun input."
            pause_continue
            return 0
        fi

        case "$BTN" in
            0) run_script "$BASE/script/maximusbat_update.sh" ;;
            1) run_script "$BASE/script/maximusbat_theme.sh" ;;
            2) run_script "$BASE/script/italian_add_images.sh" ;;
            3) menu_tools_gamepad ;;
			8) return 0 ;;
            9) exit 0 ;;
            *) ;;
        esac
    done
}

menu() {
    while true; do
        logo

        echo
        echo -e "\e[92m"
        echo "               ================================================================================="
        echo "               * Select the type of control:          *  Seleziona il tipo di controllo:       *"
        echo "               * 1. Keyboard                          *  1. Tastiera                           *"
        echo "               * 2. Gamepad                           *  2. Gamepad                            *"
        echo "               * e. Exit                              *  e. Uscita                             *"
        echo "               ================================================================================="
        echo

        read -r scelta || exit 0

        case "$scelta" in
            1) menu1 ;;
            2) menu2 ;;
            e|E) exit 0 ;;
            *) ;;
        esac
    done
}

menu