#!/bin/bash

BASE="/userdata/emulators/mbt"

read_gamepad() {

DEVICE="/dev/input/js0"

if [ ! -e "$DEVICE" ]; then
echo "No gamepad detected."
sleep 2
return 1
fi

BTN=$(jstest --event "$DEVICE" | grep -m1 "button" | awk '{print $3}')

echo $BTN

}

logo() {

echo -e "\e[32m"
echo
echo "                              ##     ## #### ##    ##  ######  ########  ##     ## "
echo "                              ###   ###  ##  ##   ##  ##    ## ##     ## ##     ## "
echo "                              #### ####  ##  ##  ##   ##       ##     ## ##     ## "
echo "                              ## ### ##  ##  #####    ##       ########  ##     ## "
echo "                              ##     ##  ##  ##  ##   ##       ##        ##     ## "
echo "                              ##     ##  ##  ##   ##  ##    ## ##        ##     ## "
echo "                              ##     ## #### ##    ##  ######  ##         #######"
echo
echo -e "\e[93m                                          PRESENT  -  PRESENTA\e[0m"
echo
echo -e "\e[91m"
echo "           ##     ##    ###    ##     ## #### ##     ## ##     ##  ######  ########     ###    ######## "
echo "           ###   ###   ## ##    ##   ##   ##  ###   ### ##     ## ##    ## ##     ##   ## ##      ##    "
echo "           #### ####  ##   ##    ## ##    ##  #### #### ##     ## ##       ##     ##  ##   ##     ##    "
echo "           ## ### ## ##     ##    ###     ##  ## ### ## ##     ##  ######  ########  ##     ##    ##    "
echo "           ##     ## #########   ## ##    ##  ##     ## ##     ##       ## ##     ## #########    ##    "
echo "           ##     ## ##     ##  ##   ##   ##  ##     ## ##     ## ##    ## ##     ## ##     ##    ##    "
echo "           ##     ## ##     ## ##     ## #### ##     ##  #######   ######  ########  ##     ##    ##    "
echo -e "\e[0m"

}

menu() {

clear
logo

echo
echo -e "\e[92m"
echo "               ================================================================================="
echo "               * Select the type of control:          *  Seleziona il tipo di controllo:       *"
echo "               * 1. Keyboard                          *  1. Tastiera                           *"
echo "               * 2. Gamepad                           *  2. Gamepad                            *"
echo "               * e. Exit                              *  e. Uscita                             *"
echo "               ================================================================================="
echo

read scelta

case $scelta in
1) menu1 ;;
2) menu2 ;;
e) exit ;;
*) menu ;;
esac

}

menu1() {

clear
logo

echo
echo -e "\e[93m"
echo "               ===================================================================================="
echo "               *                         INSTRUCTIONS / ISTRUZIONI                                *"
echo "               *                                                                                  *"
echo "               *                        - First update the tool.                                  *"
echo "               *                        - Then download the theme.                                *"
echo "               ************************************************************************************"
echo "               *                                                                                  *"
echo "               *                        - Per prima cosa aggiorna il tool.                        *"
echo "               *                        - Poi scarica il tema.                                    *"
echo "               ===================================================================================="
echo

echo -e "\e[92m"
echo "               ===================================================================================="
echo "               * Select the operation to perform:     *  Seleziona l'operazione da eseguire:      *"
echo "               * 1. Start Updater installation        *  1. Avvia installazione Updater           *"    
echo "               * 2. Start MaximusBat theme download   *  2. Avvia scaricamento tema MaximusBat    *" 
echo "               * 3. Add Images and Logos in Italian   *  3. Aggiungi immagini e loghi in Italiano *"      
echo "               * 4. Utility Programs                  *  4. Programmi Utili                       *"   
echo "               * e. Exit                              *  e. Uscita                                *"                                                         
echo "               ===================================================================================="
echo

read scelta

case $scelta in

1)
echo -e "\e[92mStarting Updater installation... - Avvio installazione Updater...\e[0m"
bash "$BASE/script/maximusbat_update.sh"
sleep 2
menu1
;;

2)
echo -e "\e[92mStarting MaximusBat theme download... - Avvio scaricamento tema MaximusBat...\e[0m"
bash "$BASE/script/maximusbat_theme.sh"
sleep 2
menu1
;;

3)
echo -e "\e[92mAdd Images and Logos in Italian... - Aggiungi immagini e loghi in Italiano ...\e[0m"
bash "$BASE/script/italian_add_images.sh"
sleep 2
menu1
;;

4)
menu_tools_keyboard
;;

b)
menu
;;

*)
menu1
;;

esac

}

menu_tools_keyboard() {

clear
logo

echo
echo -e "\e[92m"
echo "                                      UTILITY PROGRAMS / PROGRAMMI UTILI"
echo

echo -e "\e[93m"
echo "             ==================================================================================="
echo "             *                                 README / LEGGIMI                                *"
echo "             *  1 - Adds Maximusbat Service back to the Retrobat menu.                         *"       
echo "             *  2 - Sets the Retrobat startup movie.                                           *"
echo "             *  3 - Creates SysLinks for the ROM folders located on another HDD or NAS.        *"
echo "             *  4 - Change the order of the buttons for the Retrobat screen.                   *"
echo "             ***********************************************************************************"
echo "             *  1 - Riaggiunge nel menu Retrobat Il servizio Maximusbat                        *"       
echo "             *  2 - Imposta il filmato iniziale di Retrobat.                                   *"
echo "             *  3 - Crea i SysLink delle cartelle delle roms che sono su un altro HDD o Nas.   *"
echo "             *  4 - Cambia l'ordine dei pulsanti per la schermata di Retrobat.                 *"
echo "             ==================================================================================="
echo
echo
echo -e "\e[92m"
echo "             ==================================================================================="
echo "             * Select the operation to perform:     *  Seleziona l'operazione da eseguire:     *"
echo "             * 1. Add MBT Service                   *  1. Aggiungi il servizio MBT             *"     
echo "             * 2. Default intro in Retrobat         *  2. Intro predefinita in Retrobat        *" 
echo "             * 3. Create SysLinks for Roms          *  3. Crea SysLinks per Roms               *"      
echo "             * 4. Invert Buttons A / B or Z / X     *  4. Inverti Pulsanti A / B o Z / X       *"      
echo "             * b. Back                              *  b. Indietro                             *"                                                         
echo "             ==================================================================================="
echo

read scelta

case $scelta in

1)
echo -e "\e[92mAdd Maximusbat Theme Service  - Aggiungi Maximusbat Theme Service\e[0m"
bash "$BASE/script/Add-MBTService.sh"
sleep 2
menu_tools_keyboard
;;

2)
echo -e "\e[92mDefault intro video... - Video intro iniziale ...\e[0m"
bash "$BASE/script/Make_Intro.sh"
sleep 2
menu_tools_keyboard
;;

3)
echo -e "\e[92mCreate SysLinks for Roms - Crea SysLinks per Roms\e[0m"
bash "$BASE/script/RetroBat-Link-Tool.sh"
sleep 2
menu_tools_keyboard
;;

4)
echo -e "\e[92mInvert Buttons A / B or Z / X - Inverti Pulsanti A / B o Z / X\e[0m"
bash "$BASE/script/swap_buttons.sh"
sleep 2
menu_tools_keyboard
;;

b)
menu1
;;

*)
menu_tools_keyboard
;;

esac

}

menu2() {

clear
logo

echo
echo -e "\e[93m"
echo "               ===================================================================================="
echo "               *                         INSTRUCTIONS / ISTRUZIONI                                *"
echo "               *                                                                                  *"
echo "               *                        - First update the tool.                                  *"
echo "               *                        - Then download the theme.                                *"
echo "               ************************************************************************************"
echo "               *                                                                                  *"
echo "               *                        - Per prima cosa aggiorna il tool.                        *"
echo "               *                        - Poi scarica il tema.                                    *"
echo "               ===================================================================================="
echo

echo -e "\e[92m"
echo "               ===================================================================================="
echo "               * Select the operation to perform:     *  Seleziona l'operazione da eseguire:      *"
echo "               * A. Start Updater installation        *  A. Avvia installazione Updater           *"    
echo "               * B. Start MaximusBat theme download   *  B. Avvia scaricamento tema MaximusBat    *" 
echo "               * Y. Add Images and Logos in Italian   *  Y. Aggiungi immagini e loghi in Italiano *"      
echo "               * X. Utility Programs                  *  X. Programmi Utili                       *"   
echo "               * START. Exit                          *  START. Uscita                            *"
echo "               ===================================================================================="
echo

echo "Press a button on the Gamepad..."

BTN=$(read_gamepad)

case $BTN in

0)
echo -e "\e[92mStarting Updater installation... - Avvio installazione Updater...\e[0m"
bash "$BASE/script/maximusbat_update.sh"
sleep 2
menu2
;;

1)
echo -e "\e[92mStarting MaximusBat theme download... - Avvio scaricamento tema MaximusBat...\e[0m"
bash "$BASE/script/maximusbat_theme.sh"
sleep 2
menu2
;;

2)
echo -e "\e[92mAdd Images and Logos in Italian... - Aggiungi immagini e loghi in Italiano ...\e[0m"
bash "$BASE/script/italian_add_images.sh"
sleep 2
menu2
;;

3)
menu_tools_gamepad
;;

9)
exit
;;

*)
menu2
;;

esac

}
menu_tools_gamepad() {

clear
logo

echo
echo -e "\e[92m"
echo "                                      UTILITY PROGRAMS / PROGRAMMI UTILI"
echo

echo -e "\e[93m"
echo "             ==================================================================================="
echo "             *                                 README / LEGGIMI                                *"
echo "             *  1 - Adds Maximusbat Service back to the Retrobat menu.                         *"       
echo "             *  2 - Sets the Retrobat startup movie.                                           *"
echo "             *  3 - Creates SysLinks for the ROM folders located on another HDD or NAS.        *"
echo "             *  4 - Change the order of the buttons for the Retrobat screen.                   *"
echo "             ***********************************************************************************"
echo "             *  1 - Riaggiunge nel menu Retrobat Il servizio Maximusbat                        *"       
echo "             *  2 - Imposta il filmato iniziale di Retrobat.                                   *"
echo "             *  3 - Crea i SysLink delle cartelle delle roms che sono su un altro HDD o Nas.   *"
echo "             *  4 - Cambia l'ordine dei pulsanti per la schermata di Retrobat.                 *"
echo "             ==================================================================================="
echo
echo
echo -e "\e[92m"
echo "             ==================================================================================="
echo "             * Select the operation to perform:     *  Seleziona l'operazione da eseguire:     *"
echo "             * A. Add MBT Service                   *  A. Aggiungi il servizio MBT             *"     
echo "             * B. Default intro in Retrobat         *  B. Intro predefinita in Retrobat        *" 
echo "             * Y. Create SysLinks for Roms          *  Y. Crea SysLinks per Roms               *"      
echo "             * X. Invert Buttons A / B or Z / X     *  X. Inverti Pulsanti A / B o Z / X       *"      
echo "             * START. Back                          *  START. Indietro                         *"                                                         
echo "             ==================================================================================="
echo

echo "Press a button on the Gamepad..."

BTN=$(read_gamepad)

case $BTN in

0)
echo -e "\e[92mAdd Maximusbat Theme Service  - Aggiungi Maximusbat Theme Service\e[0m"
bash "$BASE/script/Add-MBTService.sh"
sleep 2
menu_tools_gamepad
;;

1)
echo -e "\e[92mDefault intro video... - Video intro iniziale ...\e[0m"
bash "$BASE/script/Make_Intro.sh"
sleep 2
menu_tools_gamepad
;;

2)
echo -e "\e[92mCreate SysLinks for Roms - Crea SysLinks per Roms\e[0m"
bash "$BASE/script/RetroBat-Link-Tool.sh"
sleep 2
menu_tools_gamepad
;;

3)
echo -e "\e[92mInvert Buttons A / B or Z / X - Inverti Pulsanti A / B o Z / X\e[0m"
bash "$BASE/script/swap_buttons.sh"
sleep 2
menu_tools_gamepad
;;

9)
menu2
;;

*)
menu_tools_gamepad
;;

esac

}

menu
