#!/bin/bash

XMLFILE="/userdata/system/es_menu/gamelist.xml"

echo "Looking for gamelist.xml at: $XMLFILE"
echo "Cerco gamelist.xml a: $XMLFILE"

if [ -f "$XMLFILE" ]; then

if grep -q "@Maximusbat Theme Updater@" "$XMLFILE"; then

echo "The entry '@Maximusbat Theme Updater@' already exists."
echo "La voce '@Maximusbat Theme Updater@' esiste gia'."

else

echo "Adding MaximusBat service..."

sed -i '/<\/gameList>/i\
    <game>\
        <path>./maximusbat-theme-updater.menu</path>\
        <name>@Maximusbat Theme Updater@</name>\
        <desc>Script to update Theme Maximusbat.</desc>\
        <image>./media/maximusbat-theme-updater-logo.png</image>\
        <marquee>./media/maximusbat-theme-updater-logo.png</marquee>\
        <rating>0</rating>\
        <releasedate />\
        <developer>MIKCPU</developer>\
        <publisher>MIKCPU</publisher>\
        <genre>Script</genre>\
        <playcount />\
        <lastplayed />\
        <gametime />\
        <lang>en</lang>\
        <region>wr</region>\
    </game>' "$XMLFILE"

echo "The entry has been added successfully."
echo "La voce è stata aggiunta correttamente."

fi

else

echo "gamelist.xml file not found."
echo "File gamelist.xml non trovato."

fi

sleep 2