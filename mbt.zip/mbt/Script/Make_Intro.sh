#!/bin/bash

VIDEO_FOLDER="/userdata/emulationstation/.emulationstation/video"
BOOT_VIDEO="/userdata/system/batocera-boot-video.mp4"

print_logo() {

printf "\e[92m  ====================================================  \e[0m\n"
printf "\e[92m  ##     ## #### ##    ##  ######  ########  ##     ##  \e[0m\n"
printf "\e[92m  ###   ###  ##  ##   ##  ##    ## ##     ## ##     ##  \e[0m\n"
printf "\e[97m  #### ####  ##  ##  ##   ##       ##     ## ##     ##  \e[0m\n"
printf "\e[97m  ## ### ##  ##  #####    ##       ########  ##     ##  \e[0m\n"
printf "\e[91m  ##     ##  ##  ##  ##   ##       ##        ##     ##  \e[0m\n"
printf "\e[91m  ##     ## #### ##    ##  ######  ##         #######   \e[0m\n"
printf "\e[91m  ====================================================  \e[0m\n"

}

if [ ! -d "$VIDEO_FOLDER" ]; then
echo "Folder video not found / Cartella video non trovata"
sleep 3
exit
fi

mapfile -t videos < <(ls "$VIDEO_FOLDER"/*.mp4 2>/dev/null | sort)

if [ ${#videos[@]} -eq 0 ]; then
echo "No videos found / Nessun video trovato"
sleep 3
exit
fi

while true
do

clear

echo
print_logo
echo

echo -e "\e[92m                 CHOOSE THE BATOCERA BOOT VIDEO\e[0m"
echo -e "\e[92m                 SCEGLI IL VIDEO DI BOOT DI BATOCERA\e[0m"
echo

i=1
for v in "${videos[@]}"
do
echo -e "\e[97m$i) $(basename "$v")\e[0m"
((i++))
done

echo
printf "\e[91m========================================================================================\e[0m\n"
printf "\e[91m|To exit without changing anything, type (e) / Per uscire senza modificare, digita (e) |\e[0m\n"
printf "\e[91m========================================================================================\e[0m\n"
echo

read -p "Enter the number of the desired video / Inserisci il numero del video desiderato: " choice

if [ "$choice" = "e" ]; then
echo "Exit without changing anything / Uscita senza modificare nulla."
exit
fi

if [[ "$choice" =~ ^[0-9]+$ ]] && [ "$choice" -ge 1 ] && [ "$choice" -le "${#videos[@]}" ]; then

selected="${videos[$((choice-1))]}"

cp "$selected" "$BOOT_VIDEO"

clear

echo
print_logo
echo

printf "\e[92m======================================================================================================\e[0m\n"
printf "\e[92m    Boot video set correctly to / Video di boot impostato correttamente a : %s\e[0m\n" "$(basename "$selected")"
printf "\e[92m======================================================================================================\e[0m\n"
echo

echo "Press Enter to exit / Premi Invio per uscire (auto chiusura in 5 secondi)..."

read -t 5

exit

else

echo -e "\e[91mInvalid selection / Scelta non valida.\e[0m"
echo -e "\e[91mPress Enter to try again... / Premi Invio per riprovare...\e[0m"
read

fi

done