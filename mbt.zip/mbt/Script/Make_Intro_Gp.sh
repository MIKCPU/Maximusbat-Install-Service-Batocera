#!/bin/bash

VIDEO_FOLDER="/userdata/emulationstation/.emulationstation/video"
BOOT_VIDEO="/userdata/system/batocera-boot-video.mp4"
DEVICE="/dev/input/js0"

if [ ! -d "$VIDEO_FOLDER" ]; then
echo "Folder video not found / Cartella video non trovata"
sleep 3
exit
fi

if [ ! -e "$DEVICE" ]; then
echo "Gamepad not detected / Gamepad non rilevato"
sleep 3
exit
fi

mapfile -t videos < <(ls "$VIDEO_FOLDER"/*.mp4 2>/dev/null | sort)

if [ ${#videos[@]} -eq 0 ]; then
echo "No videos found / Nessun video trovato"
sleep 3
exit
fi

print_logo() {

printf "\e[92m  ====================================================  \e[0m\n"
printf "\e[92m  ##     ## #### ##    ##  ######  ########  ##     ##  \e[0m\n"
printf "\e[92m  ###   ###  ##  ##   ##  ##    ## ##     ## ##     ##  \e[0m\n"
printf "\e[97m  #### ####  ##  ##  ##   ##       ##     ## ##     ##  \e[0m\n"
printf "\e[97m  ## ### ##  ##  #####    ##       ########  ##     ##  \e[0m\n"
printf "\e[91m  ##     ##  ##  ##  ##   ##       ##        ##     ##  \e[0m\n"
printf "\e[91m  ##     ## #### ##    ##  ######  ##         #######   \e[0m\n"
printf "\e[91m  ====================================================  \e[0m\n"

}

draw_menu() {

clear
echo
print_logo
echo

echo -e "\e[92m                 CHOOSE THE BATOCERA BOOT VIDEO\e[0m"
echo -e "\e[92m                 SCEGLI IL VIDEO DI BOOT DI BATOCERA\e[0m"
echo

for i in "${!videos[@]}"
do

name=$(basename "${videos[$i]}")

if [ "$i" -eq "$currentIndex" ]; then
echo -e "\e[93m > $((i+1))) $name\e[0m"
else
echo -e "\e[97m   $((i+1))) $name\e[0m"
fi

done

echo
printf "\e[91m========================================================================================\e[0m\n"
printf "\e[91m Use DPAD Up/Down or Stick Up/Down, A to select, B to exit\e[0m\n"
printf "\e[91m Usa DPAD Su/Giu o Stick Su/Giu, A per selezionare, B per uscire\e[0m\n"
printf "\e[91m========================================================================================\e[0m\n"

}

read_button() {

jstest --event "$DEVICE" | grep -m1 "button" | awk '{print $3}'

}

currentIndex=0

while true
do

draw_menu

BTN=$(read_button)

case $BTN in

0)  

selected="${videos[$currentIndex]}"

cp "$selected" "$BOOT_VIDEO"

clear
print_logo
echo
echo -e "\e[92mBoot video set correctly:\e[0m"
echo -e "\e[92mVideo di boot impostato correttamente:\e[0m"
echo
echo "$(basename "$selected")"

sleep 3
exit
;;

1)

echo
echo "Exit without changing anything / Uscita senza modificare nulla"
sleep 2
exit
;;

11)

if [ "$currentIndex" -gt 0 ]; then
((currentIndex--))
fi
;;

12)

if [ "$currentIndex" -lt $((${#videos[@]}-1)) ]; then
((currentIndex++))
fi
;;

esac

done