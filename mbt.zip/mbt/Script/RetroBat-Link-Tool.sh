#!/bin/bash

CYAN='\033[1;36m'
GRAY='\033[0;37m'
YELLOW='\033[1;33m'
GREEN='\033[1;32m'
RED='\033[1;31m'
NC='\033[0m'

title(){ echo -e "${CYAN}$1${NC}"; }
info(){ echo -e "${GRAY}$1${NC}"; }
ask(){ echo -ne "${YELLOW}$1${NC}"; }
ok(){ echo -e "${GREEN}$1${NC}"; }
warn(){ echo -e "${YELLOW}$1${NC}"; }
err(){ echo -e "${RED}$1${NC}"; }

DEFAULT_ROMS="/userdata/roms"

clear

while true
do
echo "============================================"
echo "        Batocera Link Tool"
echo "              By MIKCPU"
echo "============================================"
echo
echo "[1] English"
echo "[2] Italiano"
echo "[X] Exit"
echo

ask "Select language / Seleziona la lingua: "
read Lang

[[ "$Lang" == "1" || "$Lang" == "2" || "$Lang" == "X" ]] && break
done

[ "$Lang" = "X" ] && exit

# ---------- LANGUAGE STRINGS ----------

if [ "$Lang" = "1" ]; then

Title="Folder Link - Batocera"
Root="Enter ROMs ROOT directory"
RootSuggest="Suggested ROMs folder:"
Choose="Select folders to link"
ChooseNumbers="numbers separated by space"
Dest="Enter DESTINATION directory"
Found="Folders found:"
Creating="Creating symbolic links..."
Success="Link created successfully:"
Conflict="WARNING: already exists:"
ErrOrig="ERROR: Source path not found"
ErrDest="ERROR: Destination path not found"
Closing="Closing automatically in 3 seconds..."

else

Title="Collegamento Cartelle - Batocera"
Root="Inserisci la cartella ROOT delle ROM"
RootSuggest="Cartella ROM suggerita:"
Choose="Seleziona le cartelle da collegare"
ChooseNumbers="numeri separati da spazio"
Dest="Inserisci cartella DESTINAZIONE"
Found="Cartelle trovate:"
Creating="Creazione collegamenti simbolici..."
Success="Collegamento creato:"
Conflict="ATTENZIONE: esiste già:"
ErrOrig="ERRORE: percorso sorgente non trovato"
ErrDest="ERRORE: percorso destinazione non trovato"
Closing="Chiusura automatica tra 3 secondi..."

fi

echo
info "$RootSuggest $DEFAULT_ROMS"
ask "$Root (ENTER = default): "
read Source

[ -z "$Source" ] && Source="$DEFAULT_ROMS"

if [ ! -d "$Source" ]; then
err "$ErrOrig"
sleep 3
exit
fi

mapfile -t Folders < <(find "$Source" -mindepth 1 -maxdepth 1 -type d | sort)

clear
title "============================================"
title " $Title"
title "============================================"

echo
info "$Found ${#Folders[@]}"
echo

i=1
for f in "${Folders[@]}"
do
echo "[$i] $(basename "$f")"
((i++))
done

echo
ask "$Choose ($ChooseNumbers): "
read Selection

echo
ask "$Dest: "
read Dest

if [ ! -d "$Dest" ]; then
err "$ErrDest"
sleep 3
exit
fi

echo
info "$Creating"

for n in $Selection
do

folder="${Folders[$((n-1))]}"
name=$(basename "$folder")
target="$Dest/$name"

if [ -e "$target" ]; then
warn "$Conflict $name"
else
ln -s "$folder" "$target"
ok "$Success $name"
fi

done

echo
info "$Closing"
sleep 3