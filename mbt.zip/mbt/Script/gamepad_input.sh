#!/bin/bash

DEVICE="/dev/input/js0"

if [ ! -e "$DEVICE" ]; then
echo "No gamepad detected."
exit 0
fi

while true
do

EVENT=$(hexdump -n 8 -e '1/4 "%u " 1/2 "%u " 1/2 "%u\n"' $DEVICE 2>/dev/null)

BUTTON=$(echo $EVENT | awk '{print $4}')
VALUE=$(echo $EVENT | awk '{print $3}')

if [ "$VALUE" = "1" ]; then

case $BUTTON in

0)
exit 1   # A
;;

1)
exit 2   # B
;;

3)
exit 3   # Y
;;

2)
exit 4   # X
;;

7)
exit 5   # START
;;

esac

fi

done