#!/bin/bash

clear

echo -e "\e[91m"
echo "M   M  III  K   K CCCCC  PPPPP U   U"
echo "MM MM   I   K  K  C      P   P U   U"
echo "M M M   I   K K   C      PPPPP U   U"
echo "M   M   I   KK    C      P     U   U"
echo "M   M  III  K  K  CCCCC  P     UUUUU"
echo -e "\e[0m"

echo -e "\e[94mPresents...\e[0m"
echo -e "\e[94mPresenta...\e[0m"

echo -e "\e[91m"
echo "  ___ __  __    _    ____ _____ ____    _     ___   ____  ___    ___ _____  _    _     ___    _    _   _ "
echo " |_ _|  \/  |  / \  / ___| ____/ ___|  | |   / _ \ / ___|/ _ \  |_ _|_   _|/ \  | |   |_ _|  / \  | \ | |"
echo "  | || |\/| | / _ \| |  _|  _| \___ \  | |  | | | | |  _| | | |  | |  | | / _ \ | |    | |  / _ \ |  \| |"
echo "  | || |  | |/ ___ \ |_| | |___ ___) | | |__| |_| | |_| | |_| |  | |  | |/ ___ \| |___ | | / ___ \| |\  |"
echo " |___|_|  |_/_/   \_\____|_____|____/  |_____\___/ \____|\___/  |___| |_/_/   \_\_____|___/_/   \_\_| \_|"
echo -e "\e[0m"

echo

BASE="/userdata/themes/Maximusbat"
SCRIPT_DIR="$(dirname "$0")"

IMPORT="$SCRIPT_DIR/../../../_PreRequisites -Install First-/italian"
XML_IMPORT="$SCRIPT_DIR/../../../_PreRequisites -Install First-/XML/italian"
XML_ORIGINAL="$SCRIPT_DIR/../../../_PreRequisites -Install First-/XML/original"

LOGOS="$BASE/_inc/logos"

if [ ! -d "$IMPORT" ]; then
echo "Folder 'italian' not found."
echo "Cartella 'italian' non trovata."
sleep 3
exit
fi

mkdir -p "$LOGOS"

echo "******************************************************************************"
echo "Select : [1] Install Images in Italian, [2] Remove Images in Italian         *"
echo "Scegli : [1] Installa Immagini in Italiano, [2] Rimuovi Immagini in Italiano *"
echo "******************************************************************************"

read -p "(1/2): " MODE

if [ "$MODE" = "2" ]; then

echo
echo "REMOVAL IN PROGRESS..."
echo "RIMOZIONE IN CORSO..."

find "$LOGOS" -name "*-it.png" -delete
find "$BASE" -name "systemsnap-it.png" -delete

if [ -d "$XML_ORIGINAL" ]; then

echo
echo "Restoring original files..."
echo "Ripristino dei files originali..."

cp -r "$XML_ORIGINAL/"* "$BASE/"

fi

echo
echo "Removal completed."
echo "Rimozione completata."

sleep 3
exit

fi

echo
echo "Installing Italian images..."
echo "Installazione immagini italiane..."

for FILE in "$IMPORT"/*-it.png; do

[ -e "$FILE" ] || continue

cp -f "$FILE" "$LOGOS/"

echo "Copied: $(basename "$FILE")"
echo "Copiato: $(basename "$FILE")"

done

echo

for SYSTEM in "$IMPORT"/*; do
[ -d "$SYSTEM" ] || continue

if [ -d "$SYSTEM" ]; then

NAME=$(basename "$SYSTEM")

SRC="$SYSTEM/_inc/systemsnap-it.png"
DST="$BASE/$NAME/_inc/systemsnap-it.png"

if [ -f "$SRC" ]; then

mkdir -p "$(dirname "$DST")"

cp -f "$SRC" "$DST"

echo "Copied: $NAME systemsnap-it.png"
echo "Copiato: $NAME systemsnap-it.png"

fi

fi

done

if [ -d "$XML_IMPORT" ]; then

echo
echo "Copying XML files..."
echo "Copio i files XML..."

cp -r "$XML_IMPORT/"* "$BASE/"

fi

echo
echo "Installation completed."
echo "Installazione completata."

sleep 3
exit 0