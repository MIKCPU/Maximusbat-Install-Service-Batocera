#!/bin/bash

RED='\033[1;31m'
GREEN='\033[1;32m'
BLUE='\033[1;34m'
CYAN='\033[1;36m'
YELLOW='\033[1;33m'
NC='\033[0m'

THEME_DIR="/userdata/themes/Maximusbat"
COLLECTIONS="/userdata/system/configs/emulationstation/collections"
REPO="https://github.com/MIKCPU/Maximusbat-theme.git"
API="https://api.github.com/repos/MIKCPU/Maximusbat-Updater-Batocera/contents/system/configs/emulationstation/collections"
wait_input() {
    local show_message="${1:-true}"
    local timeout="${2:-5}"
    local start now elapsed
    start=$(date +%s)

    while true; do
        read -r -t 0.1 -n 1 _key && return 0

        if command -v jstest >/dev/null 2>&1 && [ -e /dev/input/js0 ]; then
            BTN=$(timeout 0.2 jstest --event /dev/input/js0 2>/dev/null | head -n 1)
            if echo "$BTN" | grep -qi "button"; then
                return 0
            fi
        fi

        now=$(date +%s)
        elapsed=$((now - start))

        if [ "$elapsed" -ge "$timeout" ]; then
            if [ "$show_message" = "true" ]; then
                echo -e "${YELLOW}No gamepad or key detected. Continuing...${NC}"
                echo -e "${YELLOW}Nessun gamepad o tasto rilevato. Continuo...${NC}"
            fi
            return 0
        fi
    done
}

download_file_silent() {
    local url="$1"
    local out_file="$2"

    curl -fsSL -A "Batocera Bash" "$url" -o "$out_file"
}

print_logo_small() {
    echo -e "${RED}"
    cat << "EOF"
M   M  III  K   K CCCCC  PPPPP U   U
MM MM   I   K  K  C      P   P U   U
M M M   I   K K   C      PPPPP U   U
M   M   I   KK    C      P     U   U
M   M  III  K  K  CCCCC  P     UUUUU
EOF
    echo -e "${NC}"
}

print_logo_main() {
    echo -e "${RED}"
    cat << "EOF"
  __  __   _   __  _____ __  __ _   _ ___ ___   _ _____
 |  \/  | /_\  \ \/ /_ _|  \/  | | | / __| _ ) /_\_   _|
 | |\/| |/ _ \  >  < | || |\/| | |_| \__ \ _ \/ _ \| |
 |_|  |_/_/ \_\/_/\_\___|_|  |_|\___/|___/___/_/ \_\_|
EOF
    echo -e "${NC}"
}

show_progress_bar() {
    local current="$1"
    local total="$2"
    local percent filled empty bar

    if [ "$total" -le 0 ]; then
        percent=100
    else
        percent=$(( current * 100 / total ))
    fi

    filled=$(( percent * 50 / 100 ))
    empty=$(( 50 - filled ))

    bar=$(printf "%${filled}s" "" | tr ' ' '#')
    bar="${bar}$(printf "%${empty}s" "" | tr ' ' '-')"

    printf "\r[%s] %d%%" "$bar" "$percent"
}

ALLOWED_FILES=(
"custom-007.cfg"
"custom-1970.cfg"
"custom-1970s.cfg"
"custom-1980.cfg"
"custom-1980s.cfg"
"custom-1990.cfg"
"custom-1990s.cfg"
"custom-1_player.cfg"
"custom-2000.cfg"
"custom-2000s.cfg"
"custom-2010.cfg"
"custom-2010s.cfg"
"custom-2020.cfg"
"custom-2020s.cfg"
"custom-2_player.cfg"
"custom-3players.cfg"
"custom-4players.cfg"
"custom-Adventure Time.cfg"
"custom-Albert Odyssey.cfg"
"custom-Altered Beast.cfg"
"custom-Arc the Lad.cfg"
"custom-Ayrton Senna.cfg"
"custom-Baldur's Gate.cfg"
"custom-Ben 10.cfg"
"custom-Berserk.cfg"
"custom-Bruce Lee.cfg"
"custom-Cadillacs.cfg"
"custom-California Games.cfg"
"custom-Daffy Duck.cfg"
"custom-Darkwing Duck.cfg"
"custom-Dead or Alive.cfg"
"custom-Diablo.cfg"
"custom-Dragon Ball Z.cfg"
"custom-Dragon Ball.cfg"
"custom-DuckTales.cfg"
"custom-EarthBound.cfg"
"custom-Mikcpu-Xmas-Special.cfg"
"custom-Minecraft.cfg"
"custom-SpongeBob.cfg"
"custom-Spyro.cfg"
"custom-Super Robot Wars.cfg"
"custom-Super Smash Bros.cfg"
"custom-Superman.cfg"
"custom-Ultraman.cfg"
"custom-Wacky Races.cfg"
"custom-Waluigi.cfg"
"custom-Warcraft.cfg"
"custom-Wild Arms.cfg"
"custom-Yogi Bear.cfg"
"custom-Ys.cfg"
"custom-Yu Yu Hakusho.cfg"
"custom-Yu-Gi-Oh.cfg"
"custom-ace_attorney.cfg"
"custom-action.cfg"
"custom-action_&_adventure.cfg"
"custom-addamsfamily.cfg"
"custom-adventureisland.cfg"
"custom-adventuresoflolo.cfg"
"custom-after_burner.cfg"
"custom-air_force.cfg"
"custom-aladdin.cfg"
"custom-alex_kidd.cfg"
"custom-alien.cfg"
"custom-alien_breed.cfg"
"custom-alone_in_the_dark.cfg"
"custom-animal_crossing.cfg"
"custom-arcade-classics.cfg"
"custom-arcade-killer.cfg"
"custom-arkanoid.cfg"
"custom-armored_core.cfg"
"custom-army_men.cfg"
"custom-artoffighting.cfg"
"custom-assassins_creed.cfg"
"custom-asterix_obelix.cfg"
"custom-asteroids.cfg"
"custom-avengers.cfg"
"custom-back_to_the_future.cfg"
"custom-backyard_sports.cfg"
"custom-barbarian.cfg"
"custom-barbie.cfg"
"custom-baseball.cfg"
"custom-basketball.cfg"
"custom-batman.cfg"
"custom-battletoads.cfg"
"custom-beatemup.cfg"
"custom-billiard.cfg"
"custom-bmx.cfg"
"custom-bomberman.cfg"
"custom-bowling.cfg"
"custom-boxing.cfg"
"custom-btmups_capcom.cfg"
"custom-bubblebobble.cfg"
"custom-capcom.cfg"
"custom-castlevania.cfg"
"custom-centipede.cfg"
"custom-commando.cfg"
"custom-contra.cfg"
"custom-crash.cfg"
"custom-darkstalkers.cfg"
"custom-dataeast.cfg"
"custom-disney.cfg"
"custom-donkeykong.cfg"
"custom-donkeykongcountry.cfg"
"custom-donpachi.cfg"
"custom-doom.cfg"
"custom-doubledragon.cfg"
"custom-dragon's lair.cfg"
"custom-dragonquest.cfg"
"custom-driver.cfg"
"custom-dungeons_dragons.cfg"
"custom-dynasty_warriors.cfg"
"custom-earthwormjim.cfg"
"custom-ecco_dolphin.cfg"
"custom-elder_scrolls.cfg"
"custom-fable.cfg"
"custom-fallout.cfg"
"custom-fantastic4.cfg"
"custom-fantasy.cfg"
"custom-farcry.cfg"
"custom-fatal_frame.cfg"
"custom-fatalfury.cfg"
"custom-fifa.cfg"
"custom-fighting.cfg"
"custom-finalfantasy.cfg"
"custom-finalfight.cfg"
"custom-first_person.cfg"
"custom-fishing.cfg"
"custom-flight_simulator.cfg"
"custom-flintstones.cfg"
"custom-football.cfg"
"custom-forza_motorsport.cfg"
"custom-frogger.cfg"
"custom-front_mission.cfg"
"custom-fzero.cfg"
"custom-galaga.cfg"
"custom-galaxian.cfg"
"custom-gauntlet.cfg"
"custom-ghostbusters.cfg"
"custom-ghoulsnghosts.cfg"
"custom-gijoe.cfg"
"custom-godofwar.cfg"
"custom-godzilla.cfg"
"custom-gokart.cfg"
"custom-goldenaxe.cfg"
"custom-goldensun.cfg"
"custom-goldentee.cfg"
"custom-golf.cfg"
"custom-gradius.cfg"
"custom-grandia.cfg"
"custom-granturismo.cfg"
"custom-gta.cfg"
"custom-guiltygear.cfg"
"custom-hacks.cfg"
"custom-hackslash.cfg"
"custom-halo.cfg"
"custom-harrypotter.cfg"
"custom-helicopter.cfg"
"custom-hitman.cfg"
"custom-hockey.cfg"
"custom-homebrews.cfg"
"custom-houseofthedead.cfg"
"custom-hulk.cfg"
"custom-hunting.cfg"
"custom-ik.cfg"
"custom-indianajones.cfg"
"custom-irem.cfg"
"custom-jamespond.cfg"
"custom-jojo.cfg"
"custom-jurassicpark.cfg"
"custom-kick off.cfg"
"custom-kof.cfg"
"custom-konami.cfg"
"custom-lego.cfg"
"custom-leisuresuitlarry.cfg"
"custom-lemmings.cfg"
"custom-lightgun.cfg"
"custom-lotr.cfg"
"custom-mamelite.cfg"
"custom-mario.cfg"
"custom-mariokart.cfg"
"custom-marvel.cfg"
"custom-megaman.cfg"
"custom-metalgear.cfg"
"custom-metalslug.cfg"
"custom-metroid.cfg"
"custom-midway.cfg"
"custom-monopoly.cfg"
"custom-monsterhunter.cfg"
"custom-mortalkombat.cfg"
"custom-motocross.cfg"
"custom-n64hd.cfg"
"custom-namco.cfg"
"custom-nbajam.cfg"
"custom-needforspeed.cfg"
"custom-nes-classic.cfg"
"custom-ninja.cfg"
"custom-ninjagaiden.cfg"
"custom-nintendo.cfg"
"custom-oldschool.cfg"
"custom-olympics.cfg"
"custom-outrun.cfg"
"custom-pacman.cfg"
"custom-pinball.cfg"
"custom-pitfall.cfg"
"custom-platform.cfg"
"custom-pokemon.cfg"
"custom-poker.cfg"
"custom-powerrangers.cfg"
"custom-princeofpersia.cfg"
"custom-puzzle.cfg"
"custom-racing.cfg"
"custom-rambo.cfg"
"custom-rampage.cfg"
"custom-rastan.cfg"
"custom-residentevil.cfg"
"custom-residualvm.cfg"
"custom-roadrash.cfg"
"custom-robocop.cfg"
"custom-run-and-gun.cfg"
"custom-sailormoon.cfg"
"custom-samuraishodown.cfg"
"custom-samuraiworrior.cfg"
"custom-sega.cfg"
"custom-sensiblesoccer.cfg"
"custom-shadowofthebeast.cfg"
"custom-shinobi.cfg"
"custom-shmups.cfg"
"custom-shooter.cfg"
"custom-shumps-horizontal.cfg"
"custom-shumps-vertical.cfg"
"custom-silenthill.cfg"
"custom-simpsons.cfg"
"custom-skateboard.cfg"
"custom-snes-classic.cfg"
"custom-snk.cfg"
"custom-snowboarding.cfg"
"custom-soccer.cfg"
"custom-sonic.cfg"
"custom-spaceace.cfg"
"custom-spaceinvaders.cfg"
"custom-spiderman.cfg"
"custom-sports.cfg"
"custom-startrek.cfg"
"custom-starwars.cfg"
"custom-strategy.cfg"
"custom-streetfighter.cfg"
"custom-streetsofrage.cfg"
"custom-taito.cfg"
"custom-tekken.cfg"
"custom-tennis.cfg"
"custom-terminator.cfg"
"custom-tetris.cfg"
"custom-thelastninja.cfg"
"custom-tmnt.cfg"
"custom-tombraider.cfg"
"custom-tron.cfg"
"custom-turrican.cfg"
"custom-volley.cfg"
"custom-wario.cfg"
"custom-williams.cfg"
"custom-wonderboy.cfg"
"custom-worldheroes.cfg"
"custom-worms.cfg"
"custom-wrestling.cfg"
"custom-x-men.cfg"
"custom-zelda.cfg"
)

is_allowed_file() {
    local filename="$1"
    local item
    for item in "${ALLOWED_FILES[@]}"; do
        [ "$item" = "$filename" ] && return 0
    done
    return 1
}

clear

print_logo_small
echo -e "${BLUE}Presents...${NC}"
echo -e "${BLUE}Presenta...${NC}"
print_logo_main

echo -e "${GREEN}Batocera detected at /userdata${NC}"
echo -e "${GREEN}Batocera rilevato in /userdata${NC}"

if ! curl -fsSL --connect-timeout 5 https://api.github.com >/dev/null 2>&1; then
    echo -e "${RED}ERROR: No internet connection${NC}"
    echo -e "${RED}ERRORE: Nessuna connessione internet${NC}"
    wait_input true 5
    exit 1
fi

mkdir -p "$THEME_DIR"

if [ ! -d "$THEME_DIR/.git" ]; then
    echo -e "${BLUE}Initial repository cloning...${NC}"
    echo -e "${BLUE}Clonazione iniziale del repository...${NC}"

    if ! git clone --depth 1 --recurse-submodules "$REPO" "$THEME_DIR"; then
        echo -e "${RED}ERROR: Unable to clone theme repository!${NC}"
        echo -e "${RED}ERRORE: Impossibile clonare il repository del tema!${NC}"
        exit 1
    fi
else
    echo -e "${BLUE}Checking for updates in the repository...${NC}"
    echo -e "${BLUE}Verificando aggiornamenti nel repository...${NC}"

    cd "$THEME_DIR" || exit 1

    git reset --hard HEAD >/dev/null 2>&1
    git clean -fd >/dev/null 2>&1

    if ! git pull origin main; then
        echo -e "${RED}ERROR: Unable to update theme repository!${NC}"
        echo -e "${RED}ERRORE: Impossibile aggiornare il repository del tema!${NC}"
        exit 1
    fi
fi

echo -e "${CYAN}Synchronization COLLECTIONS...${NC}"
echo -e "${CYAN}Sincronizzazione COLLECTIONS...${NC}"

mkdir -p "$COLLECTIONS"

errore=false
remote_json="$(curl -fsSL -A "Batocera Bash" "$API" 2>/dev/null)"

if [ -z "$remote_json" ]; then
    echo -e "${RED}ERROR: Unable to read 'collections' folder from GitHub!${NC}"
    echo -e "${RED}ERRORE: Impossibile leggere la cartella 'collections' da GitHub!${NC}"
    errore=true
else
    mapfile -t FILES < <(printf '%s\n' "$remote_json" | grep -o '"download_url": *"[^"]*"' | cut -d '"' -f4)
    total=${#FILES[@]}
    processed=0

    for url in "${FILES[@]}"; do
        name=$(basename "$url")
        local_file="$COLLECTIONS/$name"
        tmp=$(mktemp "/tmp/maximusbat_${name// /_}.XXXX")
        update=true

        if ! download_file_silent "$url" "$tmp"; then
            echo -e "\n${RED}ERROR: Unable to download $name${NC}"
            echo -e "${RED}ERRORE: Impossibile scaricare $name${NC}"
            errore=true
            processed=$((processed + 1))
            show_progress_bar "$processed" "$total"
            continue
        fi

        if [ -f "$local_file" ]; then
            local_hash=$(sha256sum "$local_file" 2>/dev/null | awk '{print $1}')
            remote_hash=$(sha256sum "$tmp" 2>/dev/null | awk '{print $1}')
            if [ "$local_hash" = "$remote_hash" ]; then
                update=false
            fi
        fi

        if [ "$update" = true ]; then
            if ! mv -f "$tmp" "$local_file"; then
                echo -e "\n${RED}ERROR: Unable to update $name${NC}"
                echo -e "${RED}ERRORE: Impossibile aggiornare $name${NC}"
                errore=true
                rm -f "$tmp"
            fi
        else
            rm -f "$tmp"
        fi

        processed=$((processed + 1))
        show_progress_bar "$processed" "$total"
    done

    echo ""

    while IFS= read -r -d '' lf; do
        base="$(basename "$lf")"
        if ! is_allowed_file "$base"; then
            echo -e "${RED}Removing unauthorized file: $base${NC}"
            echo -e "${RED}Rimuovo file non autorizzato: $base${NC}"
            rm -f "$lf"
        fi
    done < <(find "$COLLECTIONS" -maxdepth 1 -type f -name "*.cfg" -print0)

    if [ "$errore" = true ]; then
        echo -e "${YELLOW}Collections sync completed with errors!${NC}"
        echo -e "${YELLOW}Sincronizzazione COLLECTIONS completata con errori!${NC}"
    else
        echo -e "${GREEN}COLLECTIONS sync completed successfully!${NC}"
        echo -e "${GREEN}Sincronizzazione COLLECTIONS completata con successo!${NC}"
    fi
fi

for file in "$THEME_DIR/README.md" "$THEME_DIR/.gitattributes"; do
    if [ -f "$file" ]; then
        rm -f "$file"
        echo -e "${RED}$file deleted!${NC}"
        echo -e "${RED}$file eliminato!${NC}"
    fi
done

echo -e "${GREEN}Operation Complete!${NC}"
echo -e "${GREEN}Operazione completata!${NC}"

wait_input true 5

clear

echo -e "${GREEN}"
cat << "EOF"
 _____________________________________________________
|Thank you for downloading and installing the Theme!  |
|Grazie per aver scaricato ed installato il Tema!     |
|_____________________________________________________|
EOF
echo -e "${NC}"

print_logo_small

echo -e "${GREEN}"
cat << "EOF"
 ______________________________________________________
|Download Theme complete!                              |
|Download Tema completato!                             |
|______________________________________________________|
|Press a gamepad button or key to close!               |
|Or wait for it to close automatically!                |
|Premi un pulsante del gamepad o un tasto per chiudere!|
|O aspetta che si chiuda in automatico!                |
|______________________________________________________|
EOF
echo -e "${NC}"

wait_input false 5