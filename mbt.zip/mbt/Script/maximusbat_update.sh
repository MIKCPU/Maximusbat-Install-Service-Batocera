#!/bin/bash

RED='\033[1;31m'
GREEN='\033[1;32m'
BLUE='\033[1;34m'
YELLOW='\033[1;33m'
NC='\033[0m'

REPO="https://github.com/MIKCPU/Maximusbat-Updater-Batocera.git"
TEMP="/userdata/system/maximusbat_update_tmp"

wait_input() {

timeout=5
start=$(date +%s)

while true
do

read -t 0.1 -n 1 key && return

if [ -e /dev/input/js0 ]; then
BTN=$(jstest --event /dev/input/js0 2>/dev/null | head -n 1)
if echo "$BTN" | grep -q "button"; then
return
fi
fi

now=$(date +%s)
elapsed=$((now-start))

if [ $elapsed -ge $timeout ]; then
echo -e "${YELLOW}No gamepad or key detected. Continuing...${NC}"
echo -e "${YELLOW}Nessun gamepad o tasto rilevato. Continuo...${NC}"
return
fi

done
}

clear

echo -e "${RED}"
cat << "EOF"
M   M  III  K   K CCCCC  PPPPP U   U
MM MM   I   K  K  C      P   P U   U
M M M   I   K K   C      PPPPP U   U
M   M   I   KK    C      P     U   U
M   M  III  K  K  CCCCC  P     UUUUU
EOF
echo -e "${NC}"

echo -e "${BLUE}Presents...${NC}"
echo -e "${BLUE}Presenta...${NC}"

echo -e "${RED}"
cat << "EOF"
  __  __   _   __  _____ __  __ _   _ ___ ___   _ _____    _   _ ___ ___   _ _____ ___ ___ 
 |  \/  | /_\  \ \/ /_ _|  \/  | | | / __| _ ) /_\_   _|__| | | | _ \   \ /_\_   _| __| _ \
 | |\/| |/ _ \  >  < | || |\/| | |_| \__ \ _ \/ _ \| ||___| |_| |  _/ |) / _ \| | | _||   /
 |_|  |_/_/ \_\/_/\_\___|_|  |_|\___/|___/___/_/ \_\_|     \___/|_| |___/_/ \_\_| |___|_|_\
EOF
echo -e "${NC}"

echo -e "${GREEN}Batocera system detected.${NC}"
echo -e "${GREEN}Sistema Batocera rilevato.${NC}"

echo ""

if [ ! -d "$TEMP/.git" ]; then

echo -e "${BLUE}Cloning repository...${NC}"
echo -e "${BLUE}Clonazione repository...${NC}"

rm -rf "$TEMP"
git clone --depth 1 "$REPO" "$TEMP"

else

echo -e "${BLUE}Updating repository...${NC}"
echo -e "${BLUE}Aggiornamento repository...${NC}"

cd "$TEMP"
git pull

fi

echo ""
echo -e "${GREEN}Installing files...${NC}"
echo -e "${GREEN}Installazione file...${NC}"

cp -r "$TEMP/system/"* /userdata/system/

echo ""
echo -e "${GREEN}Operation Complete!${NC}"
echo -e "${GREEN}Operazione completata!${NC}"

wait_input

clear

echo -e "${GREEN}"
cat << "EOF"
 _____________________________________________________
|Thank you for downloading and installing the Theme!  |
|Grazie per aver scaricato ed installato il Tema!     |
|_____________________________________________________|
EOF
echo -e "${NC}"

echo -e "${RED}"
cat << "EOF"
M   M  III  K   K CCCCC  PPPPP U   U
MM MM   I   K  K  C      P   P U   U
M M M   I   K K   C      PPPPP U   U
M   M   I   KK    C      P     U   U
M   M  III  K  K  CCCCC  P     UUUUU
EOF
echo -e "${NC}"

echo -e "${GREEN}"
cat << "EOF"
 ______________________________________________________
|Download Theme complete!                              |
|Download Tema completato!                             |
|______________________________________________________|
|Press a gamepad button or key to close!               |
|Or wait for it to close automatically!                |
|Premi un pulsante del gamepad o un tasto per chiudere!|
|O aspetta che si chiuda in automatico!                |
|______________________________________________________|
EOF
echo -e "${NC}"

wait_input