#!/bin/bash

CFG="/userdata/system/configs/emulationstation/es_input.cfg"

GREEN='\033[1;32m'
WHITE='\033[1;37m'
RED='\033[1;31m'
BLUE='\033[1;34m'
NC='\033[0m'

if [ ! -f "$CFG" ]; then
    echo ""
    echo "ERRORE: es_input.cfg non trovato"
    echo "ERROR: es_input.cfg not found"
    echo ""
    echo "Percorso controllato:"
    echo "$CFG"
    sleep 5
    exit
fi

clear

printf "\n"
printf "${GREEN}  ====================================================  ${NC}\n"
printf "${GREEN}  ##     ## #### ##    ##  ######  ########  ##     ##  ${NC}\n"
printf "${GREEN}  ###   ###  ##  ##   ##  ##    ## ##     ## ##     ##  ${NC}\n"
printf "${WHITE}  #### ####  ##  ##  ##   ##       ##     ## ##     ##  ${NC}\n"
printf "${WHITE}  ## ### ##  ##  #####    ##       ########  ##     ##  ${NC}\n"
printf "${RED}  ##     ##  ##  ##  ##   ##       ##        ##     ##  ${NC}\n"
printf "${RED}  ##     ## #### ##    ##  ######  ##         #######   ${NC}\n"
printf "${RED}  ====================================================  ${NC}\n"
printf "\n"

printf "${BLUE}            CHANGE ORDER OF A/B AND Z/X BUTTONS${NC}\n"
printf "${BLUE}            CAMBIA ORDINE DEI PULSANTI A/B E Z/X${NC}\n"

printf "\n"
printf "${GREEN}           ======================================${NC}\n"
printf "${GREEN}             SELECT OPTIONS - SELEZIONA OPZIONE  ${NC}\n"
printf "${GREEN}           ======================================${NC}\n"

printf "\n"
printf "           ======================================\n"
printf "                 1  -  A / B  -  Z / X           \n"
printf "                 2  -  B / A  -  X / Z           \n"
printf "           ======================================\n"

printf "\n"
printf "${RED}           ======================================${NC}\n"
printf "${RED}                 e - Exit / Uscita               ${NC}\n"
printf "${RED}           ======================================${NC}\n"
printf "\n"

read -p "SELECT - SELEZIONA: " choice

if [ "$choice" = "e" ]; then
    echo ""
    echo "Exit without changes / Uscita senza modifiche"
    sleep 2
    exit
fi

cp "$CFG" "$CFG.bak"

if [ "$choice" = "1" ]; then

    sed -i 's/name="a".*id="[0-9]*"/name="a" id="0"/g' "$CFG"
    sed -i 's/name="b".*id="[0-9]*"/name="b" id="1"/g' "$CFG"

    echo ""
    echo "A / B - Z / X (layout applied - impostato)"

fi

if [ "$choice" = "2" ]; then

    sed -i 's/name="a".*id="[0-9]*"/name="a" id="1"/g' "$CFG"
    sed -i 's/name="b".*id="[0-9]*"/name="b" id="0"/g' "$CFG"

    echo ""
    echo "B / A - X / Z (layout applied - impostato)"

fi

echo ""
echo "Backup created - Backup creato: es_input.cfg.bak"

sleep 5