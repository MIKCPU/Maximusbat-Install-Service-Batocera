#!/bin/bash
# --- Maximusbat EmulationStation xterm launcher ---
if [ "${MBT_XTERM:-0}" != "1" ] && ps -p "$PPID" -o args= 2>/dev/null | grep -q "emulatorlauncher"; then
    exec /usr/bin/xterm -fs 16 -maximized -fg white -bg black -fa DejaVuSansMono -en UTF-8 -e env MBT_XTERM=1 /bin/bash "$0" "$@"
fi
# --- Fine launcher ---
set -e

VIDEO_FOLDER="/userdata/splash"
BOOT_VIDEO="/userdata/system/batocera-boot-video.mp4"
DEVICE="/dev/input/js0"

if [ ! -d "$VIDEO_FOLDER" ]; then
    echo "Folder video not found / Cartella video non trovata"
    sleep 3
    exit 1
fi

if [ ! -e "$DEVICE" ]; then
    echo "Gamepad not detected / Gamepad non rilevato"
    sleep 3
    exit 1
fi

if ! command -v jstest >/dev/null 2>&1; then
    echo "jstest not found - gamepad non supportato"
    sleep 3
    exit 1
fi

mapfile -t videos < <(find "$VIDEO_FOLDER" -maxdepth 1 -name "*.mp4" | sort)

if [ ${#videos[@]} -eq 0 ]; then
    echo "No videos found / Nessun video trovato"
    sleep 3
    exit 1
fi

print_logo() {
printf "\e[92m  ====================================================  \e[0m\n"
printf "\e[92m  ##     ## #### ##    ##  ######  ########  ##     ##  \e[0m\n"
printf "\e[92m  ###   ###  ##  ##   ##  ##    ## ##     ## ##     ##  \e[0m\n"
printf "\e[97m  #### ####  ##  ##  ##   ##       ##     ## ##     ##  \e[0m\n"
printf "\e[97m  ## ### ##  ##  #####    ##       ########  ##     ##  \e[0m\n"
printf "\e[91m  ##     ##  ##  ##  ##   ##       ##        ##     ##  \e[0m\n"
printf "\e[91m  ##     ## #### ##    ##  ######  ##         #######   \e[0m\n"
printf "\e[91m  ====================================================  \e[0m\n"
}

draw_menu() {
clear
echo
print_logo
echo

echo -e "\e[92m                 CHOOSE THE BATOCERA BOOT VIDEO\e[0m"
echo -e "\e[92m                 SCEGLI IL VIDEO DI BOOT DI BATOCERA\e[0m"
echo

for i in "${!videos[@]}"; do
    name=$(basename "${videos[$i]}")

    if [ "$i" -eq "$currentIndex" ]; then
        echo -e "\e[93m > $((i+1))) $name\e[0m"
    else
        echo -e "\e[97m   $((i+1))) $name\e[0m"
    fi
done

echo
printf "\e[91m========================================================================================\e[0m\n"
printf "\e[91m Use DPAD Up/Down or Stick, A to select, B to exit\e[0m\n"
printf "\e[91m Usa DPAD Su/Giu o Stick, A per selezionare, B per uscire\e[0m\n"
printf "\e[91m========================================================================================\e[0m\n"
}

read_button() {
    jstest --event "$DEVICE" 2>/dev/null | grep -m1 "button" | awk '{print $3}'
}

currentIndex=0

while true; do

    draw_menu

    BTN=$(read_button)

    case "$BTN" in

    0)  # A = seleziona
        selected="${videos[$currentIndex]}"

        mkdir -p /userdata/system
        cp -f "$selected" "$BOOT_VIDEO"

        clear
        print_logo
        echo
        echo -e "\e[92mBoot video set correctly:\e[0m"
        echo -e "\e[92mVideo di boot impostato correttamente:\e[0m"
        echo
        echo "$(basename "$selected")"

        sleep 3
        exit 0
    ;;

    1)  # B = esci
        echo
        echo "Exit without changing anything / Uscita senza modificare nulla"
        sleep 2
        exit 0
    ;;

    11) # su
        if [ "$currentIndex" -gt 0 ]; then
            ((currentIndex--))
        fi
    ;;

    12) # giù
        if [ "$currentIndex" -lt $((${#videos[@]}-1)) ]; then
            ((currentIndex++))
        fi
    ;;

    esac

    sleep 0.1

done