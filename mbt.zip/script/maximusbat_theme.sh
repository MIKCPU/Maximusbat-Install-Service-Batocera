#!/bin/bash
# --- Maximusbat EmulationStation xterm launcher ---
if [ "${MBT_XTERM:-0}" != "1" ] && ps -p "$PPID" -o args= 2>/dev/null | grep -q "emulatorlauncher"; then
    exec /usr/bin/xterm -fs 16 -maximized -fg white -bg black -fa DejaVuSansMono -en UTF-8 -e env MBT_XTERM=1 /bin/bash "$0" "$@"
fi
# --- Fine launcher ---

RED='\033[1;31m'
GREEN='\033[1;32m'
BLUE='\033[1;34m'
CYAN='\033[1;36m'
YELLOW='\033[1;33m'
NC='\033[0m'

THEME_DIR="/userdata/themes/Maximusbat"
COLLECTIONS_DIR="/userdata/system/configs/emulationstation/collections"
THEME_ZIP="/tmp/maximusbat_theme.zip"
THEME_REPO_ZIP="https://github.com/MIKCPU/Maximusbat-theme/archive/refs/heads/main.zip"
COLLECTIONS_API="https://api.github.com/repos/MIKCPU/Maximusbat-Updater-Batocera/contents/system/configs/emulationstation/collections"

ALLOWED_FILES=(
"custom-007.cfg"
"custom-1970.cfg"
"custom-1970s.cfg"
"custom-1980.cfg"
"custom-1980s.cfg"
"custom-1990.cfg"
"custom-1990s.cfg"
"custom-1_player.cfg"
"custom-2000.cfg"
"custom-2000s.cfg"
"custom-2010.cfg"
"custom-2010s.cfg"
"custom-2020.cfg"
"custom-2020s.cfg"
"custom-2_player.cfg"
"custom-3players.cfg"
"custom-4players.cfg"
"custom-Adventure Time.cfg"
"custom-Albert Odyssey.cfg"
"custom-Altered Beast.cfg"
"custom-Arc the Lad.cfg"
"custom-Ayrton Senna.cfg"
"custom-Baldur's Gate.cfg"
"custom-Ben 10.cfg"
"custom-Berserk.cfg"
"custom-Bruce Lee.cfg"
"custom-Cadillacs.cfg"
"custom-California Games.cfg"
"custom-Daffy Duck.cfg"
"custom-Darkwing Duck.cfg"
"custom-Dead or Alive.cfg"
"custom-Diablo.cfg"
"custom-Dragon Ball Z.cfg"
"custom-Dragon Ball.cfg"
"custom-DuckTales.cfg"
"custom-EarthBound.cfg"
"custom-Mikcpu-Xmas-Special.cfg"
"custom-Minecraft.cfg"
"custom-SpongeBob.cfg"
"custom-Spyro.cfg"
"custom-Super Robot Wars.cfg"
"custom-Super Smash Bros.cfg"
"custom-Superman.cfg"
"custom-Ultraman.cfg"
"custom-Wacky Races.cfg"
"custom-Waluigi.cfg"
"custom-Warcraft.cfg"
"custom-Wild Arms.cfg"
"custom-Yogi Bear.cfg"
"custom-Ys.cfg"
"custom-Yu Yu Hakusho.cfg"
"custom-Yu-Gi-Oh.cfg"
"custom-ace_attorney.cfg"
"custom-action.cfg"
"custom-action_&_adventure.cfg"
"custom-addamsfamily.cfg"
"custom-adventureisland.cfg"
"custom-adventuresoflolo.cfg"
"custom-after_burner.cfg"
"custom-air_force.cfg"
"custom-aladdin.cfg"
"custom-alex_kidd.cfg"
"custom-alien.cfg"
"custom-alien_breed.cfg"
"custom-alone_in_the_dark.cfg"
"custom-animal_crossing.cfg"
"custom-arcade-classics.cfg"
"custom-arcade-killer.cfg"
"custom-arkanoid.cfg"
"custom-armored_core.cfg"
"custom-army_men.cfg"
"custom-artoffighting.cfg"
"custom-assassins_creed.cfg"
"custom-asterix_obelix.cfg"
"custom-asteroids.cfg"
"custom-avengers.cfg"
"custom-back_to_the_future.cfg"
"custom-backyard_sports.cfg"
"custom-barbarian.cfg"
"custom-barbie.cfg"
"custom-baseball.cfg"
"custom-basketball.cfg"
"custom-batman.cfg"
"custom-battletoads.cfg"
"custom-beatemup.cfg"
"custom-billiard.cfg"
"custom-bmx.cfg"
"custom-bomberman.cfg"
"custom-bowling.cfg"
"custom-boxing.cfg"
"custom-btmups_capcom.cfg"
"custom-bubblebobble.cfg"
"custom-capcom.cfg"
"custom-castlevania.cfg"
"custom-centipede.cfg"
"custom-commando.cfg"
"custom-contra.cfg"
"custom-crash.cfg"
"custom-darkstalkers.cfg"
"custom-dataeast.cfg"
"custom-disney.cfg"
"custom-donkeykong.cfg"
"custom-donkeykongcountry.cfg"
"custom-donpachi.cfg"
"custom-doom.cfg"
"custom-doubledragon.cfg"
"custom-dragon's lair.cfg"
"custom-dragonquest.cfg"
"custom-driver.cfg"
"custom-dungeons_dragons.cfg"
"custom-dynasty_warriors.cfg"
"custom-earthwormjim.cfg"
"custom-ecco_dolphin.cfg"
"custom-elder_scrolls.cfg"
"custom-fable.cfg"
"custom-fallout.cfg"
"custom-fantastic4.cfg"
"custom-fantasy.cfg"
"custom-farcry.cfg"
"custom-fatal_frame.cfg"
"custom-fatalfury.cfg"
"custom-fifa.cfg"
"custom-fighting.cfg"
"custom-finalfantasy.cfg"
"custom-finalfight.cfg"
"custom-first_person.cfg"
"custom-fishing.cfg"
"custom-flight_simulator.cfg"
"custom-flintstones.cfg"
"custom-football.cfg"
"custom-forza_motorsport.cfg"
"custom-frogger.cfg"
"custom-front_mission.cfg"
"custom-fzero.cfg"
"custom-galaga.cfg"
"custom-galaxian.cfg"
"custom-gauntlet.cfg"
"custom-ghostbusters.cfg"
"custom-ghoulsnghosts.cfg"
"custom-gijoe.cfg"
"custom-godofwar.cfg"
"custom-godzilla.cfg"
"custom-gokart.cfg"
"custom-goldenaxe.cfg"
"custom-goldensun.cfg"
"custom-goldentee.cfg"
"custom-golf.cfg"
"custom-gradius.cfg"
"custom-grandia.cfg"
"custom-granturismo.cfg"
"custom-gta.cfg"
"custom-guiltygear.cfg"
"custom-hacks.cfg"
"custom-hackslash.cfg"
"custom-halo.cfg"
"custom-harrypotter.cfg"
"custom-helicopter.cfg"
"custom-hitman.cfg"
"custom-hockey.cfg"
"custom-homebrews.cfg"
"custom-houseofthedead.cfg"
"custom-hulk.cfg"
"custom-hunting.cfg"
"custom-ik.cfg"
"custom-indianajones.cfg"
"custom-irem.cfg"
"custom-jamespond.cfg"
"custom-jojo.cfg"
"custom-jurassicpark.cfg"
"custom-kick off.cfg"
"custom-kof.cfg"
"custom-konami.cfg"
"custom-lego.cfg"
"custom-leisuresuitlarry.cfg"
"custom-lemmings.cfg"
"custom-lightgun.cfg"
"custom-lotr.cfg"
"custom-mamelite.cfg"
"custom-mario.cfg"
"custom-mariokart.cfg"
"custom-marvel.cfg"
"custom-megaman.cfg"
"custom-metalgear.cfg"
"custom-metalslug.cfg"
"custom-metroid.cfg"
"custom-midway.cfg"
"custom-monopoly.cfg"
"custom-monsterhunter.cfg"
"custom-mortalkombat.cfg"
"custom-motocross.cfg"
"custom-n64hd.cfg"
"custom-namco.cfg"
"custom-nbajam.cfg"
"custom-needforspeed.cfg"
"custom-nes-classic.cfg"
"custom-ninja.cfg"
"custom-ninjagaiden.cfg"
"custom-nintendo.cfg"
"custom-oldschool.cfg"
"custom-olympics.cfg"
"custom-outrun.cfg"
"custom-pacman.cfg"
"custom-pinball.cfg"
"custom-pitfall.cfg"
"custom-platform.cfg"
"custom-pokemon.cfg"
"custom-poker.cfg"
"custom-powerrangers.cfg"
"custom-princeofpersia.cfg"
"custom-puzzle.cfg"
"custom-racing.cfg"
"custom-rambo.cfg"
"custom-rampage.cfg"
"custom-rastan.cfg"
"custom-residentevil.cfg"
"custom-residualvm.cfg"
"custom-roadrash.cfg"
"custom-robocop.cfg"
"custom-run-and-gun.cfg"
"custom-sailormoon.cfg"
"custom-samuraishodown.cfg"
"custom-samuraiworrior.cfg"
"custom-sega.cfg"
"custom-sensiblesoccer.cfg"
"custom-shadowofthebeast.cfg"
"custom-shinobi.cfg"
"custom-shmups.cfg"
"custom-shooter.cfg"
"custom-shumps-horizontal.cfg"
"custom-shumps-vertical.cfg"
"custom-silenthill.cfg"
"custom-simpsons.cfg"
"custom-skateboard.cfg"
"custom-snes-classic.cfg"
"custom-snk.cfg"
"custom-snowboarding.cfg"
"custom-soccer.cfg"
"custom-sonic.cfg"
"custom-spaceace.cfg"
"custom-spaceinvaders.cfg"
"custom-spiderman.cfg"
"custom-sports.cfg"
"custom-startrek.cfg"
"custom-starwars.cfg"
"custom-strategy.cfg"
"custom-streetfighter.cfg"
"custom-streetsofrage.cfg"
"custom-taito.cfg"
"custom-tekken.cfg"
"custom-tennis.cfg"
"custom-terminator.cfg"
"custom-tetris.cfg"
"custom-thelastninja.cfg"
"custom-tmnt.cfg"
"custom-tombraider.cfg"
"custom-tron.cfg"
"custom-turrican.cfg"
"custom-volley.cfg"
"custom-wario.cfg"
"custom-williams.cfg"
"custom-wonderboy.cfg"
"custom-worldheroes.cfg"
"custom-worms.cfg"
"custom-wrestling.cfg"
"custom-x-men.cfg"
"custom-zelda.cfg"
)

wait_input() {
    local show_message="${1:-true}"
    local timeout="${2:-5}"
    local start now elapsed
    start=$(date +%s)
    while true; do
        read -r -t 0.1 -n 1 _key && return 0
        now=$(date +%s)
        elapsed=$((now - start))
        if [ "$elapsed" -ge "$timeout" ]; then
            $show_message && echo -e "${YELLOW}No input detected. Continuing...${NC}"
			$show_message && echo -e "${YELLOW}Nessun input rilevato. Continuo...${NC}"
            return 0
        fi
    done
}

print_logo_small() {
echo -e "${RED}"
cat << "EOF"
M   M  III  K   K CCCCC  PPPPP U   U
MM MM   I   K  K  C      P   P U   U
M M M   I   K K   C      PPPPP U   U
M   M   I   KK    C      P     U   U
M   M  III  K  K  CCCCC  P     UUUUU
EOF
echo -e "${NC}"
}

print_logo_main() {
echo -e "${RED}"
cat << "EOF"
  __  __   _   __  _____ __  __ _   _ ___ ___   _ _____
 |  \/  | /_\  \ \/ /_ _|  \/  | | | / __| _ ) /_\_   _|
 | |\/| |/ _ \  >  < | || |\/| | |_| \__ \ _ \/ _ \| |
 |_|  |_/_/ \_\/_/\_\___|_|  |_|\___/|___/___/_/ \_\_|
EOF
echo -e "${NC}"
}

is_allowed_file() {
    local file="$1"
    for item in "${ALLOWED_FILES[@]}"; do
        [[ "$item" == "$file" ]] && return 0
    done
    return 1
}

show_progress_bar() {
    local current="$1"
    local total="$2"
    local percent filled empty bar
    percent=$(( total == 0 ? 100 : current * 100 / total ))
    filled=$(( percent * 50 / 100 ))
    empty=$((50 - filled))
    bar=$(printf "%${filled}s" "" | tr ' ' '#')
    bar="${bar}$(printf "%${empty}s" "" | tr ' ' '-')"
    printf "\r[%s] %d%%" "$bar" "$percent"
}

download_file() {
    wget --progress=bar:force --header="User-Agent: Batocera Bash" --hsts-file=/tmp/.wget-hsts "$1" -O "$2"
}
clear
print_logo_small
print_logo_main
echo -e "${CYAN}For Batocera${NC}"
echo -e "${CYAN}Per Batocera${NC}"

if ! ping -c 1 github.com &>/dev/null; then
    echo -e "${RED}ERROR: No internet connection${NC}"
    echo -e "${RED}ERRORE: Nessuna connessione internet${NC}"
    wait_input true 5
    exit 1
fi


echo -e "${BLUE}Downloading the theme...${NC}"
echo -e "${BLUE}Scaricamento del tema...${NC}"

if ! download_file "$THEME_REPO_ZIP" "$THEME_ZIP"; then
    echo -e "${RED}Theme download failed!${NC}"
    echo -e "${RED}Download del tema fallito!${NC}"
    rm -f "$THEME_ZIP"
    wait_input true 5
    exit 1
fi

# --- Scelta del disco per la cartella temporanea ---

TMP_BASES=()

# Disco principale Batocera
if [ -d "/userdata" ] && [ -w "/userdata" ]; then
    TMP_BASES+=("/userdata")
fi

# Altri dischi montati in /media
for mount_dir in /media/*; do
    [ -d "$mount_dir" ] || continue

    # Accetta solo veri punti di montaggio
    mount_point=$(findmnt -rn -T "$mount_dir" -o TARGET 2>/dev/null)
    [ "$mount_point" = "$mount_dir" ] || continue

    # Verifica che il disco sia scrivibile
    [ -w "$mount_dir" ] || continue

    TMP_BASES+=("$mount_dir")
done

# Rimuove eventuali duplicati
UNIQUE_BASES=()
for base in "${TMP_BASES[@]}"; do
    duplicate=false
    for existing in "${UNIQUE_BASES[@]}"; do
        [ "$base" = "$existing" ] && duplicate=true
    done
    [ "$duplicate" = false ] && UNIQUE_BASES+=("$base")
done

# Selezione del disco
TMP_INDEX=0

if [ "${#UNIQUE_BASES[@]}" -gt 1 ]; then
    echo ""
    echo -e "${CYAN}Select the disk for temporary files:${NC}"
    echo -e "${CYAN}Seleziona il disco per i file temporanei:${NC}"
    echo ""


for i in "${!UNIQUE_BASES[@]}"; do
    base="${UNIQUE_BASES[$i]}"

    # Spazio del disco in formato leggibile
    read -r total used avail < <(
        df -h -P "$base" 2>/dev/null |
        awk 'NR==2 {print $2, $3, $4}'
    )

    printf "\n${YELLOW}%d)${NC} %s\n" "$((i + 1))" "$base"
    echo -e "   Spazio totale / Total: ${CYAN}${total:-N/D}${NC}"
    echo -e "   Utilizzato / Used:     ${CYAN}${used:-N/D}${NC}"
    echo -e "   Libero / Available:    ${GREEN}${avail:-N/D}${NC}"
done


    echo ""
    while true; do
        read -r -p "Choice / Scegli [1-${#UNIQUE_BASES[@]}]: " choice

        if [[ "$choice" =~ ^[0-9]+$ ]] &&
           [ "$choice" -ge 1 ] &&
           [ "$choice" -le "${#UNIQUE_BASES[@]}" ]; then
            TMP_INDEX=$((choice - 1))
            break
        fi

        echo -e "${RED}Invalid choice! Scelta non valida!${NC}"
    done

elif [ "${#UNIQUE_BASES[@]}" -eq 1 ]; then
    echo -e "${CYAN}Using disk / Utilizzo disco: ${UNIQUE_BASES[0]}${NC}"
else
    echo -e "${RED}No writable disk found!${NC}"
    echo -e "${RED}Nessun disco scrivibile trovato!${NC}"
    rm -f "$THEME_ZIP"
    wait_input true 5
    exit 1
fi

TMP_ROOT="${UNIQUE_BASES[$TMP_INDEX]}/Maximusbat_tmp"
EXTRACT_DIR="$TMP_ROOT/Maximusbat-theme-main"

# Crea la cartella temporanea sul disco scelto
rm -rf "$TMP_ROOT"
mkdir -p "$TMP_ROOT" || {
    echo -e "${RED}Cannot create temporary folder!${NC}"
    echo -e "${RED}Impossibile creare la cartella temporanea!${NC}"
    rm -f "$THEME_ZIP"
    wait_input true 5
    exit 1
}

echo ""
echo -e "${BLUE}Extracting theme on / Scompattazione in:${NC}"
echo -e "${CYAN}$TMP_ROOT${NC}"

if ! unzip -q "$THEME_ZIP" -d "$TMP_ROOT"; then
    echo -e "${RED}Error extracting theme!${NC}"
    echo -e "${RED}Errore durante la scompattazione del tema!${NC}"
    rm -rf "$TMP_ROOT" "$THEME_ZIP"
    wait_input true 5
    exit 1
fi

# Verifica che la cartella estratta esista
if [ ! -d "$EXTRACT_DIR" ]; then
    echo -e "${RED}Extracted theme folder not found!${NC}"
    echo -e "${RED}Cartella del tema scompattato non trovata!${NC}"
    rm -rf "$TMP_ROOT" "$THEME_ZIP"
    wait_input true 5
    exit 1
fi

# Installa il tema nella destinazione definitiva
mkdir -p "$THEME_DIR"

if ! rsync -av --update "$EXTRACT_DIR/" "$THEME_DIR/"; then
    echo -e "${RED}Theme installation failed!${NC}"
    echo -e "${RED}Installazione del tema fallita!${NC}"
    rm -rf "$TMP_ROOT" "$THEME_ZIP"
    wait_input true 5
    exit 1
fi

# Pulizia dei file temporanei
rm -rf "$TMP_ROOT" "$THEME_ZIP"

echo -e "${GREEN}Theme installed in $THEME_DIR${NC}"
echo -e "${GREEN}Tema installato in $THEME_DIR${NC}"


mkdir -p "$COLLECTIONS_DIR"
echo -e "${BLUE}Synchronizing collections intelligently...${NC}"
echo -e "${BLUE}Sincronizzazione intelligente delle collezioni...${NC}"
errore=false

REPO_BASE_RAW="https://raw.githubusercontent.com/MIKCPU/Maximusbat-Updater-Batocera/main/userdata/system/configs/emulationstation/collections"

FILES=$(wget -qO- "$REPO_BASE_RAW" | grep -oP 'title="\K[^"]+\.cfg')
total=$(echo "$FILES" | wc -l)
processed=0

while read -r name; do
    [ -z "$name" ] && continue

    if ! is_allowed_file "$name"; then
        echo -e "${YELLOW}Skipped unauthorized file: $name${NC}"
        echo -e "${YELLOW}File non autorizzato saltato: $name${NC}"
		
        processed=$((processed + 1))
        show_progress_bar "$processed" "$total"
        continue
    fi

    tmp_file=$(mktemp "/tmp/maximusbat_${name// /_}.XXXX")
    url="$REPO_BASE_RAW/$name"

    if download_file "$url" "$tmp_file"; then
        if [ -f "$COLLECTIONS_DIR/$name" ]; then
            if ! cmp -s "$tmp_file" "$COLLECTIONS_DIR/$name"; then
                mv -f "$tmp_file" "$COLLECTIONS_DIR/$name"
                echo -e "${YELLOW}Updated: $name${NC}"
                echo -e "${YELLOW}Aggiornato: $name${NC}"
				
            else
                rm -f "$tmp_file"
                echo -e "${CYAN}Unchanged: $name${NC}"
                echo -e "${CYAN}Invariato: $name${NC}"
            fi
        else
            mv -f "$tmp_file" "$COLLECTIONS_DIR/$name"
            echo -e "${GREEN}Added: $name${NC}"
            echo -e "${GREEN}Aggiunto: $name${NC}"
        fi
    else
        echo -e "${RED}Failed to download: $name${NC}"
        echo -e "${RED}Download fallito: $name${NC}"
        errore=true
    fi

    processed=$((processed + 1))
    show_progress_bar "$processed" "$total"
done <<< "$FILES"
echo ""

if [ "$errore" = true ]; then
    echo -e "${YELLOW}Collections sync completed with errors!${NC}"
    echo -e "${YELLOW}Sincronizzazione delle collections completata con errori!${NC}"
else
    echo -e "${GREEN}Collections synchronized successfully!${NC}"
    echo -e "${GREEN}Collections sincronizzate correttamente!${NC}"
fi

while IFS= read -r -d '' lf; do
    base="$(basename "$lf")"
    if ! is_allowed_file "$base"; then
        echo -e "${RED}Removing unauthorized file: $base${NC}"
        echo -e "${RED}Rimozione file non autorizzato: $base${NC}"
        rm -f "$lf"
    fi
done < <(find "$COLLECTIONS_DIR" -maxdepth 1 -type f -name "*.cfg" -print0)

if [ "$errore" = true ]; then
    echo -e "${YELLOW}Collections sync completed with errors!${NC}"
    echo -e "${YELLOW}Sincronizzazione delle collection completata con errori!${NC}"
else
    echo -e "${GREEN}Collections synchronized successfully!${NC}"
    echo -e "${GREEN}Collections sincronizzate con successo!${NC}"
fi

for file in "$THEME_DIR/README.md" "$THEME_DIR/.gitattributes"; do
    [ -f "$file" ] && rm -f "$file"
done

echo -e "${GREEN}Operation Complete!${NC}"
echo -e "${GREEN}Operazione completata!${NC}"
wait_input true 5

echo -e "${GREEN}"
cat << "EOF"
 _____________________________________________________
|                                                     |
|Thank you for downloading and installing the Theme!  |
|Grazie per aver scaricato ed installato il Tema!     |
|_____________________________________________________|
EOF
echo -e "${NC}"

print_logo_small

echo -e "${GREEN}"
cat << "EOF"
 ______________________________________________________
|                                                      |
|Download Theme complete!                              |
|Download Tema completato!                             |
|______________________________________________________|
|                                                      |
|Press a gamepad button or key to close!               |
|Or wait for it to close automatically!                |
|Premi un pulsante del gamepad o un tasto per chiudere!|
|O aspetta che si chiuda in automatico!                |
|______________________________________________________|
EOF
echo -e "${NC}"

wait_input false 5