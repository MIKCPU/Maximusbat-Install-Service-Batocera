#!/bin/bash
# --- Maximusbat EmulationStation xterm launcher ---
if [ "${MBT_XTERM:-0}" != "1" ] && ps -p "$PPID" -o args= 2>/dev/null | grep -q "emulatorlauncher"; then
    exec /usr/bin/xterm -fs 16 -maximized -fg white -bg black -fa DejaVuSansMono -en UTF-8 -e env MBT_XTERM=1 /bin/bash "$0" "$@"
fi
# --- Fine launcher ---

# ============================================================
# CONFIGURAZIONE +MBT
# ============================================================

BATOCERA_CONF="/userdata/system/batocera.conf"

if [ -f "$BATOCERA_CONF" ]; then
    if ! grep -qE '^[[:space:]]*\+mbt\.emulator=sh[[:space:]]*$' "$BATOCERA_CONF"; then
        echo "" >> "$BATOCERA_CONF"
        echo "# Maximusbat +MBT" >> "$BATOCERA_CONF"
        echo "+mbt.emulator=sh" >> "$BATOCERA_CONF"
        echo "[Maximusbat] +mbt.emulator=sh aggiunto a batocera.conf."
    else
        echo "[Maximusbat] +mbt.emulator=sh già presente."
    fi
else
    echo "[Maximusbat] ATTENZIONE: batocera.conf non trovato."
fi

# =================================
# | Maximusbat Updater - Batocera |
# =================================

RED='\033[1;31m'
GREEN='\033[1;32m'
BLUE='\033[1;34m'
YELLOW='\033[1;33m'
WHITE='\033[1;37m'
NC='\033[0m'

GITHUB_REMOTE="github:MIKCPU/Maximusbat-Updater-Batocera/main/userdata"

wait_input() {
    timeout=5
    start=$(date +%s)

    while true
    do
        read -t 0.1 -n 1 key && return

        if [ -e /dev/input/js0 ]; then
            BTN=$(jstest --event /dev/input/js0 2>/dev/null | head -n 1)
            if echo "$BTN" | grep -q "button"; then 
                return
            fi
        fi

        now=$(date +%s)
        elapsed=$((now-start))
        if [ $elapsed -ge $timeout ]; then
		    echo -e "${YELLOW}No gamepad or key detected. Continued...${NC}"
            echo -e "${YELLOW}Nessun gamepad o tasto rilevato. Continuo...${NC}"
            return
        fi
    done
}

clear

echo -e "${RED}"
cat << "EOF"
M   M  III  K   K CCCCC  PPPPP U   U
MM MM   I   K  K  C      P   P U   U
M M M   I   K K   C      PPPPP U   U
M   M   I   KK    C      P     U   U
M   M  III  K  K  CCCCC  P     UUUUU
EOF
echo -e "${NC}"

echo -e "${BLUE}Presents...${NC}"
echo -e "${BLUE}Presenta...${NC}"

echo -e "${RED}"
cat << "EOF"
  __  __   _   __  _____ __  __ _   _ ___ ___   _ _____    _   _ ___ ___   _ _____ ___ ___ 
 |  \/  | /_\  \ \/ /_ _|  \/  | | | / __| _ ) /_\_   _|__| | | | _ \   \ /_\_   _| __| _ \
 | |\/| |/ _ \  >  < | || |\/| | |_| \__ \ _ \/ _ \| ||___| |_| |  _/ |) / _ \| | | _||   /
 |_|  |_/_/ \_\/_/\_\___|_|  |_|\___/|___/___/_/ \_\_|     \___/|_| |___/_/ \_\_| |___|_|_\
EOF
echo -e "${NC}"

echo -e "${GREEN}Batocera system detected.${NC}"
echo -e "${GREEN}Sistema Batocera rilevato.${NC}"
echo ""

echo -e "${WHITE}File synchronization from repository...${NC}"
echo -e "${WHITE}Sincronizzazione file da repository...${NC}"

TMP_DIR="/userdata/system/maximusbat_update_temp"
REPO_ZIP="$TMP_DIR/maximusbat.zip"
EXTRACTED_DIR="$TMP_DIR/Maximusbat-Updater-Batocera-main"

mkdir -p "$TMP_DIR"

if [ ! -f "$REPO_ZIP" ]; then
    echo -e "${BLUE}Downloading repository...${NC}"
    echo -e "${BLUE}Scaricando repository...${NC}"
    wget -O "$REPO_ZIP" "https://github.com/MIKCPU/Maximusbat-Updater-Batocera/archive/refs/heads/main.zip" --progress=bar:force --hsts-file=/dev/null 2>&1
    if [ $? -ne 0 ]; then
        echo -e "${RED}Error downloading!${NC}"
        echo -e "${RED}Errore durante il download!${NC}"
        exit 1
    fi
else
    echo -e "${YELLOW}ZIP already exists, skipping download.${NC}"
    echo -e "${YELLOW}ZIP già presente, salto il download.${NC}"
fi

if [ ! -d "$EXTRACTED_DIR" ]; then
    echo -e "${BLUE}Extracting files...${NC}"
    echo -e "${BLUE}Estrazione file...${NC}"
    unzip -o "$REPO_ZIP" -d "$TMP_DIR" >/dev/null 2>&1
    if [ $? -ne 0 ]; then
        echo -e "${RED}Error extracting!${NC}"
        echo -e "${RED}Errore durante l'estrazione!${NC}"
        exit 1
    fi
else
    echo -e "${YELLOW}Files already extracted, skipping extraction.${NC}"
    echo -e "${YELLOW}File già estratti, salto l'estrazione.${NC}"
fi

USERDATA_DIR="$EXTRACTED_DIR/userdata"
SYSTEM_DIR="$USERDATA_DIR/system"
SPLASH_DIR="$USERDATA_DIR/splash"

SYNC_LOG_SYSTEM="/userdata/system/.maximusbat_synced_system.txt"
SYNC_LOG_SPLASH="/userdata/system/.maximusbat_synced_splash.txt"

sync_with_output() {
    SRC_DIR="$1"
    DEST_DIR="$2"
    LOG_FILE="$3"

    if [ -d "$SRC_DIR" ]; then
        echo -e "${GREEN}Checking files in: $SRC_DIR${NC}"
		echo -e "${GREEN}Controllo dei file in: $SRC_DIR${NC}"
        find "$SRC_DIR" -type f | while read -r FILE; do
            REL_PATH="${FILE#$SRC_DIR/}"
            DEST_FILE="$DEST_DIR/$REL_PATH"

            echo -e "${WHITE}Checking: $REL_PATH${NC}"
			echo -e "${WHITE}Controllo: $REL_PATH${NC}"

            if [ ! -f "$DEST_FILE" ]; then
                mkdir -p "$(dirname "$DEST_FILE")"
                cp -f "$FILE" "$DEST_FILE"
                echo "$REL_PATH" >> "$LOG_FILE"
                echo -e "${BLUE}Copied missing: $REL_PATH${NC}"
				echo -e "${BLUE}Copia mancante: $REL_PATH${NC}"
            else
                echo -e "${YELLOW}Already exists:  $REL_PATH${NC}"
				echo -e "${YELLOW}Esiste già: $REL_PATH${NC}"
            fi
        done
    else
        echo -e "${YELLOW}Source folder not found: $SRC_DIR${NC}"
		echo -e "${YELLOW}Cartella di origine non trovata: $SRC_DIR${NC}"
    fi
}

sync_with_output "$SYSTEM_DIR" "/userdata/system" "$SYNC_LOG_SYSTEM"
sync_with_output "$SPLASH_DIR" "/userdata/splash" "$SYNC_LOG_SPLASH"

if [ -f "$SYNC_LOG_SYSTEM" ] || [ -f "$SYNC_LOG_SPLASH" ]; then
    echo -e "${GREEN}All files verified. Cleaning temporary folder...${NC}"
	echo -e "${GREEN}All files verified. Cleaning temporary folder...${NC}"
    rm -rf "$TMP_DIR"
else
    echo -e "${YELLOW}No new files were copied. Temporary folder preserved for next run.${NC}"
	echo -e "${YELLOW}Nessun nuovo file è stato copiato. Cartella temporanea conservata per la prossima esecuzione.${NC}"
fi

echo -e "${GREEN}Operation completed!${NC}"
echo -e "${GREEN}Operazione completata!${NC}"

wait_input

clear
echo -e "${GREEN}"
cat << "EOF"
 _____________________________________________________________
|                                                             |
|Thank you for downloading and installing the Theme Updater!  |
|Grazie per aver scaricato ed installato l'Aggiorna Tema!     |
|_____________________________________________________________|
EOF
echo -e "${NC}"

echo -e "${RED}"
cat << "EOF"
M   M  III  K   K CCCCC  PPPPP U   U
MM MM   I   K  K  C      P   P U   U
M M M   I   K K   C      PPPPP U   U
M   M   I   KK    C      P     U   U
M   M  III  K  K  CCCCC  P     UUUUU
EOF
echo -e "${NC}"

echo -e "${GREEN}"
cat << "EOF"
______________________________________________________
|Download Theme Updater complete!                    |
|Download Aggiorna Tema completato!                  |
|____________________________________________________|
EOF
echo -e "${NC}"

wait_input
echo -e "${GREEN}Script completed successfully!${NC}"
echo -e "${GREEN}Script terminato con successo!${NC}"
sleep 2
exit 0