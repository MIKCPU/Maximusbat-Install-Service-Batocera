#!/bin/bash
# --- Maximusbat EmulationStation xterm launcher ---
if [ "${MBT_XTERM:-0}" != "1" ] && ps -p "$PPID" -o args= 2>/dev/null | grep -q "emulatorlauncher"; then
    exec /usr/bin/xterm -fs 16 -maximized -fg white -bg black -fa DejaVuSansMono -en UTF-8 -e env MBT_XTERM=1 /bin/bash "$0" "$@"
fi
# --- Fine launcher ---

CFG="/userdata/system/configs/emulationstation/es_input.cfg"

GREEN='\033[1;32m'
WHITE='\033[1;37m'
RED='\033[1;31m'
BLUE='\033[1;34m'
NC='\033[0m'

# Controllo file
if [ ! -f "$CFG" ]; then
    echo ""
    echo "ERRORE: es_input.cfg non trovato"
    echo "ERROR: es_input.cfg not found"
    echo ""
    echo "Percorso controllato:"
    echo "$CFG"
    sleep 5
    exit 1
fi

clear

# Header
printf "\n"
printf "${GREEN}  ====================================================  ${NC}\n"
printf "${GREEN}  ##     ## #### ##    ##  ######  ########  ##     ##  ${NC}\n"
printf "${GREEN}  ###   ###  ##  ##   ##  ##    ## ##     ## ##     ##  ${NC}\n"
printf "${WHITE}  #### ####  ##  ##  ##   ##       ##     ## ##     ##  ${NC}\n"
printf "${WHITE}  ## ### ##  ##  #####    ##       ########  ##     ##  ${NC}\n"
printf "${RED}  ##     ##  ##  ##  ##   ##       ##        ##     ##  ${NC}\n"
printf "${RED}  ##     ## #### ##    ##  ######  ##         #######   ${NC}\n"
printf "${RED}  ====================================================  ${NC}\n"
printf "\n"

printf "${BLUE}   CHANGE ORDER OF A/B AND Z/X BUTTONS${NC}\n"
printf "${BLUE}   CAMBIA ORDINE DEI PULSANTI A/B E Z/X${NC}\n"

printf "\n"
printf "${GREEN}   ======================================${NC}\n"
printf "${GREEN}     SELECT OPTIONS - SELEZIONA OPZIONE  ${NC}\n"
printf "${GREEN}   ======================================${NC}\n"

printf "\n"
printf "     ======================================\n"
printf "           1  -  A / B  -  Z / X           \n"
printf "           2  -  B / A  -  X / Z           \n"
printf "     ======================================\n"

printf "\n"
printf "${RED}   ======================================${NC}\n"
printf "${RED}         e - Exit / Uscita               ${NC}\n"
printf "${RED}   ======================================${NC}\n"
printf "\n"

read -p "SELECT - SELEZIONA: " choice

# Controllo input
if [[ "$choice" != "1" && "$choice" != "2" && "$choice" != "e" ]]; then
    echo ""
    echo "Invalid option / Opzione non valida"
    sleep 2
    exit 1
fi

# Uscita
if [ "$choice" = "e" ]; then
    echo ""
    echo "Exit without changes / Uscita senza modifiche"
    sleep 2
    exit 0
fi

# Backup con timestamp
BACKUP="$CFG.bak.$(date +%Y%m%d_%H%M%S)"
cp "$CFG" "$BACKUP"

# Funzione modifica sicura
update_button() {
    local name=$1
    local id=$2
    sed -i "s/\(name=\"$name\"[^>]*id=\"\)[0-9]*\"/\1$id\"/" "$CFG"
}

# Scelta layout
if [ "$choice" = "1" ]; then

    update_button "a" 0
    update_button "b" 1
    update_button "x" 0
    update_button "z" 1

    echo ""
    echo "A / B - Z / X (layout applied - impostato)"

elif [ "$choice" = "2" ]; then

    update_button "a" 1
    update_button "b" 0
    update_button "x" 1
    update_button "z" 0

    echo ""
    echo "B / A - X / Z (layout applied - impostato)"

fi

echo ""
echo "Backup created - Backup creato:"
echo "$BACKUP"

sleep 5
exit 0