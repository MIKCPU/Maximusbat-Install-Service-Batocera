#!/bin/bash

CFG="/userdata/system/configs/emulationstation/es_input.cfg"
JS="/dev/input/js0"

GREEN='\033[1;32m'
WHITE='\033[1;37m'
RED='\033[1;31m'
BLUE='\033[1;34m'
NC='\033[0m'

# Controllo file config
if [ ! -f "$CFG" ]; then
    echo ""
    echo "ERRORE: es_input.cfg non trovato"
    echo "ERROR: es_input.cfg not found"
    echo ""
    echo "Percorso controllato:"
    echo "$CFG"
    sleep 5
    exit 1
fi

# Controllo joystick
if [ ! -e "$JS" ]; then
    echo ""
    echo "ERRORE: Controller non trovato"
    echo "ERROR: Controller not found"
    echo ""
    echo "Device:"
    echo "$JS"
    sleep 5
    exit 1
fi

clear

# Header
printf "\n"
printf "${GREEN}  ====================================================  ${NC}\n"
printf "${GREEN}  ##     ## #### ##    ##  ######  ########  ##     ##  ${NC}\n"
printf "${GREEN}  ###   ###  ##  ##   ##  ##    ## ##     ## ##     ##  ${NC}\n"
printf "${WHITE}  #### ####  ##  ##  ##   ##       ##     ## ##     ##  ${NC}\n"
printf "${WHITE}  ## ### ##  ##  #####    ##       ########  ##     ##  ${NC}\n"
printf "${RED}  ##     ##  ##  ##  ##   ##       ##        ##     ##  ${NC}\n"
printf "${RED}  ##     ## #### ##    ##  ######  ##         #######   ${NC}\n"
printf "${RED}  ====================================================  ${NC}\n"
printf "\n"

printf "${BLUE}   CHANGE ORDER OF A/B AND Z/X BUTTONS${NC}\n"
printf "${BLUE}   CAMBIA ORDINE DEI PULSANTI A/B E Z/X${NC}\n"

printf "\n"
printf "${GREEN}   ======================================${NC}\n"
printf "${GREEN}     USE CONTROLLER - USA IL CONTROLLER  ${NC}\n"
printf "${GREEN}   ======================================${NC}\n"

printf "\n"
printf "     ======================================\n"
printf "       A  ->  A / B  -  Z / X               \n"
printf "       B  ->  B / A  -  X / Z               \n"
printf "       START -> EXIT                       \n"
printf "     ======================================\n"
printf "\n"

echo "Waiting controller input..."

choice=""

# Funzione modifica sicura
update_button() {
    local name=$1
    local id=$2
    sed -i "s/\(name=\"$name\"[^>]*id=\"\)[0-9]*\"/\1$id\"/" "$CFG"
}

# Loop input controller
while true
do
    BTN=$(jstest --event "$JS" 2>/dev/null | head -n 1)

    if echo "$BTN" | grep -q "button 0 pressed"; then
        choice="1"
        break
    fi

    if echo "$BTN" | grep -q "button 1 pressed"; then
        choice="2"
        break
    fi

    if echo "$BTN" | grep -q "button 7 pressed"; then
        echo ""
        echo "Exit without changes / Uscita senza modifiche"
        sleep 2
        exit 0
    fi

    sleep 0.1
done

# Backup con timestamp
BACKUP="$CFG.bak.$(date +%Y%m%d_%H%M%S)"
cp "$CFG" "$BACKUP"

# Scelta layout
if [ "$choice" = "1" ]; then

    update_button "a" 0
    update_button "b" 1
    update_button "x" 0
    update_button "z" 1

    echo ""
    echo "A / B - Z / X (layout applied - impostato)"

elif [ "$choice" = "2" ]; then

    update_button "a" 1
    update_button "b" 0
    update_button "x" 1
    update_button "z" 0

    echo ""
    echo "B / A - X / Z (layout applied - impostato)"

fi

echo ""
echo "Backup created - Backup creato:"
echo "$BACKUP"

sleep 5
exit 0